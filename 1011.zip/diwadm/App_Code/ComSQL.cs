﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Data;

/// <summary>
/// Summary description for ComSQL
/// </summary>
public static class ComSQL
{
    #region " table name "
    public const string TABLE_PAINTER = "painter";
    public const string TABLE_MEMBER = "member";
    public const string TABLE_ADS = "ads";
    public const string TABLE_CONFIG = "config";
    public const string TABLE_PRODUCT = "product";
    public const string TABLE_ORDER = "`order`";
    public const string TABLE_ORDER_DETAIL = "order_detail";
    public const string TABLE_BANK_REMIT_RECORD = "bank_remit_record";
    public const string TABLE_CATEGORY = "category";
    public const string TABLE_HTML = "html";    
    #endregion

    #region " member "
    public static DataTable Member_Count()
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select count(*) from {0}", TABLE_MEMBER);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static DataTable Member_Query(string offset, string rows, string where)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select * from {0} {3} limit {1},{2}", TABLE_MEMBER, offset, rows, where);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static int Member_ActiveMember(clsMember m)
    {
        string cmdSql = string.Format("update {0} set active = 'Y' where user_name='{1}'", TABLE_MEMBER, m.user_name);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);        
    }

    public static int Member_DeactiveMember(clsMember m)
    {
        string cmdSql = string.Format("update {0} set active = 'N' where user_name='{1}'", TABLE_MEMBER, m.user_name);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);         
    }

    public static int Member_Delete(clsMember m)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("delete from {0} where user_name='{1}'", TABLE_MEMBER, m.user_name);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);         
    }

    public static int Member_Update(clsMember m)
    {
        MySqlUpdate update = new MySqlUpdate(TABLE_MEMBER);

        foreach (var prop in m.GetType().GetProperties())
        {
            update.Add(prop.Name, prop.GetValue(m, null));
        }

        update.Remove("verify");

        string cmdSql = update.ToString() + " where user_name='" + m.user_name + "'";

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }
    #endregion

    #region " ads "
    public static DataTable Ads_Count(string kind)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select count(*) from {0} where kind='{1}'", TABLE_ADS, kind);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }
    public static DataTable Ads_Query(string kind, string offset, string rows)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select * from {0} where kind='{1}' order by ads_id limit {2},{3}", TABLE_ADS, kind, offset, rows);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }
    public static int Ads_Update(clsAds ads)
    {
        MySqlUpdate update = new MySqlUpdate(TABLE_ADS);

        foreach (var prop in ads.GetType().GetProperties())
        {
            if (prop.Name == "image_url" && prop.GetValue(ads, null).ToString().Length == 0)
                continue;

            update.Add(prop.Name, prop.GetValue(ads, null));
          
        }

        update.Remove("product_marquee");

        string cmdSql = update.ToString() + " where ads_id='" + ads.ads_id + "'";

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Ads_Add(clsAds ads)
    {
        MySqlInsert ins = new MySqlInsert(TABLE_ADS);

        foreach (var prop in ads.GetType().GetProperties())
        {
            ins.Add(prop.Name, prop.GetValue(ads, null));
        }

        ins.Remove("product_marquee");

        string cmdSql = ins.ToString();

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Ads_Open(clsAds ads)
    {
        string cmdSql = string.Format("update {0} set status = 'Y' where ads_id='{1}'", TABLE_ADS, ads.ads_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Ads_Close(clsAds ads)
    {
        string cmdSql = string.Format("update {0} set status = 'N' where ads_id='{1}'", TABLE_ADS, ads.ads_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Ads_Delete(clsAds ads)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("delete from {0} where ads_id='{1}'", TABLE_ADS, ads.ads_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);         
    }
    #endregion

    #region " config "
    public static string Config_GetValue(string item)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select value from {0}", TABLE_CONFIG);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt.Rows[0].ItemArray[0].ToString();
    }
    public static int Config_SetValue(string item, string value)
    {
        string cmdSql = string.Format("update {0} set value = '{2}' where item='{1}'", TABLE_CONFIG, item, value);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }
    #endregion

    #region " order "
    public static DataTable Order_Query(string offset, string rows, string where)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select {0}.*, `{1}`.real_name, `{1}`.user_name, {5}.make_type, {5}.painter_cover, {5}.product_type, {5}.shelf_seq, {5}.order_detail_id, {5}.shelf from {0}, `{1}`, {5} where {0}.user_id = `{1}`.user_id and {0}.order_id = {5}.order_master_id {4} and {0}.status <> 'open' and {0}.status <> 'delete' group by {0}.order_id limit {2},{3} ", TABLE_ORDER, TABLE_MEMBER, offset, rows, where, TABLE_ORDER_DETAIL);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }
    public static DataTable OrderDetail_Query(string order_master_id)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select * from {0} where order_master_id='{1}'", TABLE_ORDER_DETAIL, order_master_id);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }
    public static int Order_Open(clsOrder order)
    {
        string cmdSql = string.Format("update {0} set status = 'open' where order_id='{1}'", TABLE_ORDER, order.order_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Order_Close(clsOrder order)
    {
        string cmdSql = string.Format("update {0} set status = 'close' where order_id='{1}'", TABLE_ORDER, order.order_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Order_Delete(clsOrder order)
    {        
        string cmdSql = string.Format("update {0} set status='delete' where order_id='{1}'", TABLE_ORDER, order.order_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);              
    }

    public static int Order_Update(clsOrder order)
    {
        MySqlUpdate update = new MySqlUpdate(TABLE_ORDER);

        foreach (var prop in order.GetType().GetProperties())
        {
            update.Add(prop.Name, prop.GetValue(order, null));
        }

        update.Remove("order_id");

        string cmdSql = update.ToString() + " where order_id='" + order.order_id + "'";

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int OrderDetail_Update(string order_id, string status)
    {
        string cmdSql = string.Format("update {0} set status='{2}' where order_master_id='{1}'", TABLE_ORDER_DETAIL, order_id, status);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int OrderDetail_Update(clsOrderDetail orderDetail)
    {
        MySqlUpdate update = new MySqlUpdate(TABLE_ORDER_DETAIL);

        foreach (var prop in orderDetail.GetType().GetProperties())
        {
            update.Add(prop.Name, prop.GetValue(orderDetail, null));
        }

        update.Remove("order_master_id");
        update.Remove("order_detail_id");

        string cmdSql = update.ToString() + " where order_master_id='" + orderDetail.order_master_id + "' and order_detail_id='" + orderDetail.order_detail_id + "'";

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static DataTable Product_Shelf()
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select order_detail_id, shelf_seq, painter_cover from {0} where shelf='Y' order by shelf_seq", TABLE_ORDER_DETAIL);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static int Shelf_Update(string status, string order_detail_id)
    {
        string cmdSql = string.Format("update {0} set shelf='{1}' where order_detail_id='{2}'", TABLE_ORDER_DETAIL, status, order_detail_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int ResortShelfSeq_Update(string id, int seq)
    {
        string cmdSql = string.Format("update {0} set shelf_seq='{1}' where order_detail_id='{2}'", TABLE_ORDER_DETAIL, seq, id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }
    #endregion

    #region " category "
    public static DataTable Category_List()
    {
        DataTable dt = new DataTable();
        //js for each 有分大小寫
        string cmdSql = string.Format("select category from {0} group by category order by category_id", TABLE_CATEGORY);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static DataTable Category_Menu()
    {
        DataTable dt = new DataTable();
        //js for each 有分大小寫
        string cmdSql = string.Format("select category_id, category from {0} group by category order by category_id", TABLE_CATEGORY);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static DataTable Category_Query(string offset, string rows)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select * from {0} order by category_id limit {1},{2} ", TABLE_CATEGORY, offset, rows);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static int Category_Active(clsCategory ct)
    {
        string cmdSql = string.Format("update {0} set status = 'Y' where category_id='{1}'", TABLE_CATEGORY, ct.category_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Category_Deactive(clsCategory ct)
    {
        string cmdSql = string.Format("update {0} set status = 'N' where category_id='{1}'", TABLE_CATEGORY, ct.category_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Category_Delete(clsCategory ct)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("delete from {0} where category_id='{1}'", TABLE_CATEGORY, ct.category_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Category_Update(clsCategory ct)
    {
        MySqlUpdate update = new MySqlUpdate(TABLE_CATEGORY);

        foreach (var prop in ct.GetType().GetProperties())
        {
            update.Add(prop.Name, prop.GetValue(ct, null));
        }

        update.Remove("category_id");

        string cmdSql = update.ToString() + " where category_id='" + ct.category_id + "'";

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Category_New(clsCategory ct)
    {
        MySqlInsert ins = new MySqlInsert(TABLE_CATEGORY);

        foreach (var prop in ct.GetType().GetProperties())
        {
            if (prop.Name == "category")
                ins.Add(prop.Name, prop.GetValue(ct, null));
        }

        ins.Remove("category_id");

        string cmdSql = ins.ToString();

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Category_Add(clsCategory ct)
    {
        MySqlInsert ins = new MySqlInsert(TABLE_CATEGORY);

        foreach (var prop in ct.GetType().GetProperties())
        {
            ins.Add(prop.Name, prop.GetValue(ct, null));
        }

        ins.Remove("category_id");

        string cmdSql = ins.ToString();

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static DataTable Category_Exist(clsCategory ct)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select * from {0} where category='{1}'", TABLE_CATEGORY, ct.category.Trim());
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static int Html_Save(clsCategory ct)
    {
        MySqlUpdate update = new MySqlUpdate(TABLE_CATEGORY);

        foreach (var prop in ct.GetType().GetProperties())
        {
            update.Add(prop.Name, prop.GetValue(ct, null));
        }

        string cmdSql = update.ToString() + " where category_id='" + ct.category_id + "'";

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static DataTable Html_GetContent(clsCategory ct)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select category, html, html_status from {0} where category_id='{1}'", TABLE_CATEGORY, ct.category_id);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }

    public static int Category_OpenContent(string category)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("update {0} set html_status='Y' where category='{1}'", TABLE_CATEGORY, category);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Category_CloseContent(string category)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("update {0} set html_status='N' where category='{1}'", TABLE_CATEGORY, category);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }
    #endregion

    #region " product "
    public static DataTable Product_Query(string offset, string rows, string where)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("select * from {0} {3} order by prod_id limit {1},{2} ", TABLE_PRODUCT, offset, rows, where);
        dt = MySqlDbAccess.ExcuteQueryData(cmdSql, false);
        return dt;
    }
    public static int Product_Open(clsProduct product)
    {
        string cmdSql = string.Format("update {0} set status = 'Y' where prod_id='{1}'", TABLE_PRODUCT, product.prod_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Product_Close(clsProduct product)
    {
        string cmdSql = string.Format("update {0} set status = 'N' where prod_id='{1}'", TABLE_PRODUCT, product.prod_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Product_Delete(clsProduct product)
    {
        DataTable dt = new DataTable();
        string cmdSql = string.Format("delete from {0} where prod_id='{1}'", TABLE_PRODUCT, product.prod_id);
        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Product_Update(clsProduct product)
    {
        MySqlUpdate update = new MySqlUpdate(TABLE_PRODUCT);

        foreach (var prop in product.GetType().GetProperties())
        {
            update.Add(prop.Name, prop.GetValue(product, null));
        }

        string cmdSql = update.ToString() + " where prod_id='" + product.prod_id + "'";

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }

    public static int Product_Add(clsProduct product)
    {
        MySqlInsert ins = new MySqlInsert(TABLE_PRODUCT);

        foreach (var prop in product.GetType().GetProperties())
        {
            ins.Add(prop.Name, prop.GetValue(product, null));
        }

        ins.Remove("prod_id");

        string cmdSql = ins.ToString();

        return MySqlDbAccess.ExecuteNonQueryInt(cmdSql, false);
    }
    #endregion
}