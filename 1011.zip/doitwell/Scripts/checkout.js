﻿var total = 0;

$("#continue_edit_btn").button();
$("#checkout_get_remit_number").button();

function setStorage(name, value, expires) {
    var date = new Date();
    var schedule = Math.round((date.setSeconds(date.getSeconds() + expires)) / 1000);
    localStorage.setItem(name, value);
    localStorage.setItem(name + '_time', schedule);
}

function getStorage(name) {
    return localStorage.getItem(name);
}

function clearUserName() {
    localStorage.user_name = '';
    localStorage.before_login_url = '';
    return false;
}

$("#checkout_get_remit_number").click(function () {

    var deliver_val = '';
    var radio_label = $("#radio input[type='radio']:checked").attr('id');
    if (radio_label == undefined) {
        alert("請選擇要 寄送 或 自取 !");
        return
    }

    if (radio_label == "radio1")
        deliver_val = "ship"
    else
        deliver_val = "yself"

    var get_order_id = url.parse(location.search);
    var notes = new Array();
    var n = $("#order_information_table").find("textarea");
    $.each(n, function (k, v) {
        var temp = n[k];
        notes.push(temp.name + '|' + temp.value.replace(/\n/g, ';'));
    });

    var shelfs = new Array();
    var n2 = $("#order_information_table").find(".chkShelf");
    $.each(n2, function () {        
        shelfs.push(this.id + '|' + this.checked);
    });

    $.getJSON('HandlerCheckout.ashx?action=update_order_status&order_id=' + get_order_id.get.order_id + '&receiver_name=' + $("#receiver_name").val() + '&mobile=' + $("#mobile").val() + '&email=' + $("#email").val() + '&zipcode=' + $("#zipcode").val() + '&city=' + $("#city").val() + '&locality=' + $("#locality").val() + '&address=' + $("#address").val() + '&deliver_type=' + deliver_val + '&notes[]=' + notes + '&shelfs[]=' + shelfs, {}, function (data) {
        if (data.id == '000')
            window.location.href = 'checkout_confirm.aspx?user_id=' + getStorage('user_id') + '&order_id=' + get_order_id.get.order_id + '&make_type=' + get_order_id.get.make_type;
    });
    //window.location.href = 'checkout_confirm.aspx?user_id=159';
});

$("#continue_edit_btn").click(function () {
    window.location.href = 'category.aspx?category_id='+getStorage('before_category_id');
});

$("#checkout_cancel").click(function () {
    window.location.href = 'membercenter.aspx';
});

function delete_checkout_item(id) {
    $.ajax({
        dataType: "json",
        url: 'HandlerCheckout.ashx?action=delete_item&order_detail_id=' + id,            
        success: function (data) {
            console.log(data);				          
            if(data.id=='000'){
                location.reload();
            };
            if(data.id != '000'){
                $("#system_message").slideDown().html(data.message);
            };
        }
    });
  };      