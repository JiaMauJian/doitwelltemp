﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public partial class checkout_confirm : System.Web.UI.Page
{
    public string strHtml;
    public string session_user_name;
    public string category_name;
    public string jsonCheckOut;
    public string receiver_name;  

    protected void Page_Load(object sender, EventArgs e)
    {
        string user_id = Request.QueryString["user_id"];
        string order_master_id = Request.QueryString["order_id"];
        string user_name = ComSQL.Member_GetUserName(user_id);
        string make_type = Request.QueryString["make_type"];

        // 更新user_name供前台作品欣賞使用
        ComSQL.OrderDetail_UpdateUserName(order_master_id, user_name);

        if (make_type != "painter")
            ComSQL.OrderDetail_UpdatePainterId(order_master_id, Session["EditorId"].ToString());

        DataTable dt;
        dt = ComSQL.OrderCheckout_Query(user_id, order_master_id);

        if (dt.Rows.Count == 0)
        {
            jsonCheckOut = JsonConvert.SerializeObject("");
            return;
        }

        dynamic jsonUser = new JObject();
        jsonUser.Add("order_master_id", dt.Rows[0]["order_master_id"].ToString());
        jsonUser.Add("user_id", dt.Rows[0]["user_id"].ToString());
        jsonUser.Add("receiver_name", dt.Rows[0]["receiver_name"].ToString());
        receiver_name = dt.Rows[0]["receiver_name"].ToString();
        
        jsonUser.Add("telephone", dt.Rows[0]["telephone"].ToString());
        jsonUser.Add("mobile", dt.Rows[0]["mobile"].ToString());
        jsonUser.Add("email", dt.Rows[0]["email"].ToString());
        jsonUser.Add("zipcode", dt.Rows[0]["zipcode"].ToString());
        jsonUser.Add("city", dt.Rows[0]["city"].ToString());
        jsonUser.Add("locality", dt.Rows[0]["locality"].ToString());
        jsonUser.Add("address", dt.Rows[0]["address"].ToString());
        jsonUser.Add("deliver_type", dt.Rows[0]["deliver_type"].ToString());
        jsonUser.Add("order_detail_list", new JArray());        

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            var jsonOrderDetails = new JObject();
            jsonOrderDetails.Add("order_detail_id", dt.Rows[i]["order_detail_id"].ToString());
            jsonOrderDetails.Add("product_type", dt.Rows[i]["product_type"].ToString());
            jsonOrderDetails.Add("product_spec", dt.Rows[i]["product_spec"].ToString());
            jsonOrderDetails.Add("width", dt.Rows[i]["width"].ToString());
            jsonOrderDetails.Add("height", dt.Rows[i]["height"].ToString());
            jsonOrderDetails.Add("bleed_width", dt.Rows[i]["bleed_width"].ToString());
            jsonOrderDetails.Add("bleed_height", dt.Rows[i]["bleed_height"].ToString());
            jsonOrderDetails.Add("pages", dt.Rows[i]["pages"].ToString());
            jsonOrderDetails.Add("product_amount", dt.Rows[i]["product_amount"].ToString());
            jsonOrderDetails.Add("product_price", dt.Rows[i]["product_price"].ToString());
            jsonOrderDetails.Add("product_discount", dt.Rows[i]["product_discount"].ToString());
            jsonOrderDetails.Add("note", dt.Rows[i]["note1"].ToString().Replace(";", "</br>"));
            jsonOrderDetails.Add("painter_cover", dt.Rows[i]["painter_cover"].ToString());
            jsonOrderDetails.Add("confirm_order_detail_id", dt.Rows[i]["confirm_order_detail_id"].ToString());
            jsonOrderDetails.Add("make_type", dt.Rows[i]["make_type"].ToString());
            //jsonUser.order_detail_list.Add(jsonOrderDetails);
            jsonUser["order_detail_list"].Add(jsonOrderDetails);
        }

        jsonCheckOut = JsonConvert.SerializeObject(jsonUser);

        //將訂單細項狀態改為 checkout_confirm
        ComSQL.OederDetail_UpdateCheckoutConfirm(order_master_id);

        //單頭狀態設成 inproc
        ComSQL.Oeder_UpdateInProc(user_id, order_master_id);

        if (make_type == "painter")
        {
            //將剩餘編輯中的再開一張單頭 狀態為open
            dt = ComSQL.OrderNoneCloseWorkList_Query(user_id, order_master_id);

            if (dt.Rows.Count > 0)
            {
                jsonUser.Remove("order_master_id");
                jsonUser.Remove("order_detail_list");

                //取得新的單頭ID
                dt = ComSQL.OrderOpen_QueryByUserId(user_id);
                string new_order_id = string.Empty;
                if (dt.Rows.Count == 0)
                {
                    ComSQL.Order_Create(jsonUser);
                    new_order_id = ComSQL.OrderMasterId_Query(user_id);
                }
                else
                {
                    new_order_id = ComSQL.OrderMasterId_Query(user_id);
                }

                // 把剩餘的工作清單放到新開的單頭中
                dt = ComSQL.OrderNoneCloseWorkList_Query(user_id, order_master_id);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    // 砍掉原單中的細項，已經搬移到新單頭
                    ComSQL.OrderDetail_Delete(dt.Rows[i]["order_detail_id"].ToString());

                    var jsonNewOrderDetails = new JObject();
                    jsonNewOrderDetails.Add("order_master_id", new_order_id);
                    jsonNewOrderDetails.Add("product_type", dt.Rows[i]["product_type"].ToString());
                    jsonNewOrderDetails.Add("product_spec", dt.Rows[i]["product_spec"].ToString());
                    jsonNewOrderDetails.Add("width", dt.Rows[i]["width"].ToString());
                    jsonNewOrderDetails.Add("height", dt.Rows[i]["height"].ToString());
                    jsonNewOrderDetails.Add("bleed_width", dt.Rows[i]["bleed_width"].ToString());
                    jsonNewOrderDetails.Add("bleed_height", dt.Rows[i]["bleed_height"].ToString());
                    jsonNewOrderDetails.Add("pages", dt.Rows[i]["pages"].ToString());
                    jsonNewOrderDetails.Add("product_amount", dt.Rows[i]["product_amount"].ToString());
                    jsonNewOrderDetails.Add("product_price", dt.Rows[i]["product_price"].ToString());
                    jsonNewOrderDetails.Add("product_discount", dt.Rows[i]["product_discount"].ToString());
                    jsonNewOrderDetails.Add("note", dt.Rows[i]["note"].ToString().Replace("\n", "</br>").Replace("\r\n", "</br>"));
                    jsonNewOrderDetails.Add("painter_cover", dt.Rows[i]["painter_cover"].ToString());
                    jsonNewOrderDetails.Add("painter_status", dt.Rows[i]["painter_status"].ToString());

                    string order_detail_status = dt.Rows[i]["status1"].ToString();
                    if (order_detail_status == "incar") //下次再買改回open
                        jsonNewOrderDetails.Add("status", "open");
                    else
                        jsonNewOrderDetails.Add("status", order_detail_status);

                    jsonNewOrderDetails.Add("painter_id", dt.Rows[i]["painter_id"].ToString());
                    jsonNewOrderDetails.Add("artist", dt.Rows[i]["artist"].ToString());

                    //在新單頭產生新的細項
                    ComSQL.OrderDetail_Create(jsonNewOrderDetails);
                }
            }
        }
        else
        {
            ComSQL.OrderDetail_DeleteForMakeType(order_master_id);
        }

        //更新單頭金額
        string totalMoney = ComSQL.OrderDetail_PriceQuery(order_master_id);
        ComSQL.Order_UpdateTotalMoney(order_master_id, totalMoney);
    }
}