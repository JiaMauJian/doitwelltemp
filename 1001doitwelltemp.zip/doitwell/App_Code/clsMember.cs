﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsMember
/// </summary>
public class clsMember
{
    public string user_id { get; set; }
    public string real_name { get; set; }
    public string user_name { get; set; }
    public string password { get; set; }
    public string gender { get; set; }
    public string birthday_year { get; set; }
    public string birthday_month { get; set; }
    public string birthday_day { get; set; }
    public string telephone { get; set; }
    public string mobile { get; set; }
    public string email { get; set; }
    public string city { get; set; }
    public string zipcode { get; set; }
    public string locality { get; set; }
    public string address { get; set; }
    public string active { get; set; }
    public string createtime { get; set; }
    public string verify { get; set; }
    public string discount { get; set; }
    public string register_source { get; set; }
}