﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GVar
/// </summary>
public static class GVar
{
    //Json Object
    public static int JFAIL = 0;
    public static int JRTN_MSG = 1;
    public static int JDATA_OBJ = 2;
}