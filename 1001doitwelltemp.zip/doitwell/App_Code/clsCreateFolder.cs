﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsCreateFolder
/// </summary>
public class clsCreateFolder
{
    public string user_name { get; set; }
    public string category_name { get; set; }
    public string CKBaseURL { get; set; }
    public string CKBaseDIR { get; set; }
}