using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public partial class checkout : System.Web.UI.Page
{
    public string strHtml;
    public string session_user_name;
    public string category_name;
    public string jsonCheckOut;

    protected void Page_Load(object sender, EventArgs e)
    {
        string order_master_id = Request.QueryString["order_id"];

        DataTable dt;
        dt = ComSQL.OrderFinish_Query(order_master_id);

        if (dt.Rows.Count == 0)
        {
            jsonCheckOut = JsonConvert.SerializeObject("");
            return;
        }

        dynamic jsonUser = new JObject();
        jsonUser.Add("order_master_id", dt.Rows[0]["order_master_id"].ToString());
        jsonUser.Add("receiver_name", dt.Rows[0]["receiver_name"].ToString());
        jsonUser.Add("telephone", dt.Rows[0]["telephone"].ToString());
        jsonUser.Add("mobile", dt.Rows[0]["mobile"].ToString());
        jsonUser.Add("email", dt.Rows[0]["email"].ToString());
        jsonUser.Add("zipcode", dt.Rows[0]["zipcode"].ToString());
        jsonUser.Add("city", dt.Rows[0]["city"].ToString());
        jsonUser.Add("locality", dt.Rows[0]["locality"].ToString());
        jsonUser.Add("address", dt.Rows[0]["address"].ToString());
        jsonUser.Add("order_detail_list", new JArray());

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            var jsonOrderDetails = new JObject();
            jsonOrderDetails.Add("order_detail_id", dt.Rows[i]["order_detail_id"].ToString());
            jsonOrderDetails.Add("product_type", dt.Rows[i]["product_type"].ToString());    
            jsonOrderDetails.Add("product_spec", dt.Rows[i]["product_spec"].ToString());
            jsonOrderDetails.Add("width", dt.Rows[i]["width"].ToString());
            jsonOrderDetails.Add("height", dt.Rows[i]["height"].ToString());
            jsonOrderDetails.Add("bleed_width", dt.Rows[i]["bleed_width"].ToString());
            jsonOrderDetails.Add("bleed_height", dt.Rows[i]["bleed_height"].ToString());
            jsonOrderDetails.Add("pages", dt.Rows[i]["pages"].ToString());
            jsonOrderDetails.Add("product_amount", dt.Rows[i]["product_amount"].ToString());
            jsonOrderDetails.Add("product_price", dt.Rows[i]["product_price"].ToString());
            jsonOrderDetails.Add("product_discount", dt.Rows[i]["product_discount"].ToString());
            jsonOrderDetails.Add("note", dt.Rows[i]["note"].ToString().Replace("\n", "</br>").Replace("\r\n", "</br>"));
            jsonOrderDetails.Add("make_type", dt.Rows[i]["make_type"].ToString());

            if (jsonOrderDetails["make_type"].ToString() == "painter")
            {
                string painter_id = dt.Rows[i]["painter_id"].ToString();
                jsonOrderDetails.Add("painter_cover", ComSQL.Painter_GetCover(painter_id));
                ComSQL.OederDetail_UpdatePainterCover(jsonOrderDetails["order_detail_id"].ToString(), jsonOrderDetails["painter_cover"].ToString());
            }
            else
            {
                jsonOrderDetails.Add("painter_cover", "140.116.86.167:2688/Images/logo01.png");
                ComSQL.OederDetail_UpdatePainterCover(jsonOrderDetails["order_detail_id"].ToString(), jsonOrderDetails["painter_cover"].ToString());
            }

            jsonOrderDetails.Add("painter_id", dt.Rows[i]["painter_id"].ToString());

            jsonUser["order_detail_list"].Add(jsonOrderDetails);
        }

        jsonCheckOut = JsonConvert.SerializeObject(jsonUser);
    }
}