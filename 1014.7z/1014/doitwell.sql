-- --------------------------------------------------------
-- 主機:                           127.0.0.1
-- 服務器版本:                        5.0.51b-community-nt-log - MySQL Community Edition (GPL)
-- 服務器操作系統:                      Win32
-- HeidiSQL 版本:                  8.1.0.4545
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 導出  表 doitwell.order 結構
CREATE TABLE IF NOT EXISTS `order` (
  `order_id` int(10) NOT NULL auto_increment,
  `user_id` int(10) NOT NULL,
  `confirm_order_id` varchar(50) default NULL,
  `receiver_name` varchar(50) default NULL COMMENT 'user can change the name by order, default is while he/she real_name at register/',
  `email` varchar(50) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL COMMENT 'Default is show register mobile, but he/she can change number by order',
  `zipcode` int(5) default NULL,
  `city` varchar(10) default NULL,
  `locality` varchar(10) default NULL,
  `address` varchar(128) default NULL,
  `payment_type` varchar(128) default NULL COMMENT 'BANK/POST/WEB ATM/CREADIT CARD',
  `bank_account` varchar(45) default NULL COMMENT 'bank',
  `remit_total_money` float(9,2) default '0.00',
  `order_total_money` float(9,2) default '0.00',
  `discount` float(9,2) default '1.00',
  `use_coupon` varchar(2) default 'N',
  `coupon_discount` float(9,2) default '1.00',
  `status` varchar(10) default 'open' COMMENT 'open(開單) / close(結單) / cancel(取消整張訂單) / payment(已付款) / deliver(出貨中) / return(退件)',
  `open_time` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `close_time` timestamp NULL default NULL,
  `cancel_time` timestamp NULL default NULL,
  `payment_time` timestamp NULL default NULL,
  `deliver_time` timestamp NULL default NULL,
  `return_time` timestamp NULL default NULL,
  `note` text,
  `deliver_type` varchar(50) default NULL COMMENT 'ship (寄送) / yslef (自取)',
  PRIMARY KEY  (`order_id`),
  KEY `user_id_mobile` (`user_id`,`mobile`)
) ENGINE=MyISAM AUTO_INCREMENT=229 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.order 的資料：3 rows
DELETE FROM `order`;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` (`order_id`, `user_id`, `confirm_order_id`, `receiver_name`, `email`, `telephone`, `mobile`, `zipcode`, `city`, `locality`, `address`, `payment_type`, `bank_account`, `remit_total_money`, `order_total_money`, `discount`, `use_coupon`, `coupon_discount`, `status`, `open_time`, `close_time`, `cancel_time`, `payment_time`, `deliver_time`, `return_time`, `note`, `deliver_type`) VALUES
	(49, 160, NULL, 'painter測試', '', '', '', 0, '', '', '', NULL, NULL, 0.00, 0.00, 1.00, 'N', 1.00, 'open', '2013-09-26 15:19:22', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;


-- 導出  表 doitwell.order_detail 結構
CREATE TABLE IF NOT EXISTS `order_detail` (
  `order_master_id` int(10) NOT NULL,
  `order_detail_id` int(10) NOT NULL auto_increment,
  `confirm_order_detail_id` varchar(50) default NULL,
  `product_type` varchar(128) default NULL,
  `product_spec` text NOT NULL,
  `product_amount` int(10) NOT NULL default '1',
  `product_price` float(9,2) NOT NULL default '0.00',
  `product_discount` float(9,2) default '0.00',
  `use_coupon` varchar(2) default 'N',
  `coupon_discount` float(9,2) default '0.00',
  `width` float NOT NULL,
  `height` float NOT NULL,
  `bleed_width` float NOT NULL,
  `bleed_height` float NOT NULL,
  `pages` int(11) default '1',
  `note` text,
  `painter_status` varchar(50) default 'open' COMMENT 'open(未編輯) / finish(完成製作) / close(下訂單) / edit(編輯中) / complete(完成製作for自編和委託)',
  `painter_id` varchar(50) default NULL,
  `painter_cover` text,
  `make_type` varchar(50) default 'painter' COMMENT 'painter (線上編輯) / user_editor (自編上傳) / boss_editor (委託編輯)',
  `status` varchar(50) default 'open' COMMENT 'open (開單) / close (結單) / cancel(取消訂單) / checkout(下訂單) /checkout_confirm (確定下訂拿匯款帳號)',
  `user_name` varchar(50) default NULL,
  `artist` varchar(2) default 'N',
  `cancel_order_comment` text,
  `shelf` varchar(1) default 'N' COMMENT '前台作品欣賞上下架設定',
  `shelf_seq` int(11) default NULL,
  PRIMARY KEY  (`order_detail_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1693 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.order_detail 的資料：5 rows
DELETE FROM `order_detail`;
/*!40000 ALTER TABLE `order_detail` DISABLE KEYS */;
INSERT INTO `order_detail` (`order_master_id`, `order_detail_id`, `confirm_order_detail_id`, `product_type`, `product_spec`, `product_amount`, `product_price`, `product_discount`, `use_coupon`, `coupon_discount`, `width`, `height`, `bleed_width`, `bleed_height`, `pages`, `note`, `painter_status`, `painter_id`, `painter_cover`, `make_type`, `status`, `user_name`, `artist`, `cancel_order_comment`, `shelf`, `shelf_seq`) VALUES
	(49, 282, NULL, '無框畫', '封膜', 1, 1000.00, 1.00, 'N', 0.00, 11, 22, 0, 0, 10, NULL, 'edit', '1380294122258', 'http://140.116.86.167:2688/upload/ads_images/product/13024.jpg', 'painter', 'open', 'open', 'N', NULL, 'N', NULL),
	(49, 283, NULL, '無框畫', '護角', 1, 2000.00, 0.00, 'N', 0.00, 33, 33, 0, 0, 20, NULL, 'edit', '1380296267168', 'http://140.116.86.167:2688/upload/ads_images/product/13024.jpg', 'painter', 'open', 'open', 'N', NULL, 'N', NULL),
	(49, 309, NULL, '無框畫', '封膜', 1, 1000.00, 1.00, 'N', 0.00, 11, 22, 0, 0, 10, NULL, 'edit', '1381462372797', 'http://140.116.86.167:2688/upload/ads_images/product/13024.jpg', 'painter', 'open', 'open', 'N', NULL, 'N', NULL);
/*!40000 ALTER TABLE `order_detail` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
