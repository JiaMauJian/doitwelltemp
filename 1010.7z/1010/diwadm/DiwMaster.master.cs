﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Newtonsoft.Json;

public partial class DiwMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable dt;
        dt = ComSQL.Category_Menu();

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            if (i == 0)
                Menu1.FindItem("content").NavigateUrl = "ContentAdmin.aspx?category_id=" + dt.Rows[i].ItemArray[0].ToString() + "&category=" + dt.Rows[i].ItemArray[1].ToString();

            Menu1.FindItem("content").ChildItems.Add(new MenuItem(dt.Rows[i].ItemArray[1].ToString(), "", "Images/right-arr.png", "ContentAdmin.aspx?category_id=" + dt.Rows[i].ItemArray[0].ToString() + "&category=" + dt.Rows[i].ItemArray[1].ToString()));
        }
    }
}
