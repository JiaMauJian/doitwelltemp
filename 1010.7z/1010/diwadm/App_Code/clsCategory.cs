﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsCategory
/// </summary>
public class clsCategory
{
    public int category_id { get; set; }
    public string category { get; set; }
    public string title { get; set; }
    public string content { get; set; }
    public string image_url { get; set; }
    public string html { get; set; }
    public string status { get; set; }
    public string html_status { get; set; }
}