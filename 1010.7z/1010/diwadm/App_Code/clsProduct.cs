﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsProduct
/// </summary>
public class clsProduct
{
    public int prod_id { get; set; }
    public string category { get; set; }
    public double width { get; set; }
    public double height { get; set; }
    public double bleed_width { get; set; }
    public double bleed_height { get; set; }
    public int pages { get; set; }
    public string spec { get; set; }
    public double discount { get; set; }
    public double price { get; set; }
    public int default_amount { get; set; }
}