﻿var upload_file_name;
var category_id;

$("#add_new_category_btn").click(function () {

    if ($.trim($("#add_form").find("input[name=add_new_category]").val()) == '') {
        $("#system_message").slideDown().html("請輸入產品");
        return false;
    };

    $("input[name=add_new_category]").hide();
    var json = {};
    json.category = $("input[name=add_new_category]").val();
    var json = jQuery.parseJSON(JSON.stringify(json));

    $("select[name=category]").append('<option value="' + $("input[name=add_new_category]").val() + '" label="' + $("input[name=add_new_category]").val() + '"></option>');

    $.ajax({
        dataType: "json",
        url: 'HandlerCategoryAdm.ashx?action=category_new',
        data: json,
        success: function (data) {
            if (data.id == '000') {         
                $('#dg').datagrid('reload');                
            } else {
                $("#system_message").slideDown().html(data.message);
                return false;
            }
        }
    });

    $("#system_message").hide();

});
$("#add_category_btn").click(function(){
    $("input[name=add_new_category]").show();
    $("#add_new_category_btn").show();
});

$("#add_button").click(function () {
    upload_file_name = $("tr[class='template-download'] > td[class='name'] > a").html();
    var json = {};
    json.category = $.trim($("#add_form").find("input[name=category]").val());
    //json.title = $.trim($("#add_form").find("input[name=title]").val());
    json.title = $.trim($("#add_form").find("input[name=category]").val());
    json.content = $.trim($("#add_form").find("textarea[name=content]").val().replace(/\n/g, "<br>"));
    json.image_url = 'upload/category_images/' + upload_file_name;

    var json = jQuery.parseJSON(JSON.stringify(json));

    $("#preview_image_for_edit img").attr('src', '');
    $("button[data-type]").trigger('click');

    $.ajax({
        dataType: "json",
        url: 'HandlerCategoryAdm.ashx?action=category_add',
        data: json,
        success: function (data) {
            if (data.id == '000') {
                alert(data.message);
                location.reload();
                return false;
            };
            if (data.id != '000') {
                $("#system_message").slideDown().html(data.message);

            };
        }
    });
});

$("#update_button").click(function () {
    upload_file_name = $("tr[class='template-download'] > td[class='name'] > a").html();
    var json = {};
    json.category_id = category_id;
    json.category = $.trim($("#add_form").find("input[name=category]").val());
    //json.title = $.trim($("#add_form").find("input[name=title]").val());
    json.title = $.trim($("#add_form").find("input[name=category]").val());
    json.content = $.trim($("#add_form").find("textarea[name=content]").val().replace(/\n/g, "<br>"));
    if (upload_file_name == undefined) 
    {
        json.image_url = $("#preview_image_for_edit img").attr('src');        
    }
    else 
    {
        json.image_url = 'upload/category_images/' + upload_file_name;
    }

    var json = jQuery.parseJSON(JSON.stringify(json));

    $("#preview_image_for_edit img").attr('src', '');
    $("button[data-type]").trigger('click');

    $.ajax({
        dataType: "json",
        url: 'HandlerCategoryAdm.ashx?action=category_update',
        data: json,
        success: function (data) {
            if (data.id == '000') {
                alert(data.message);
                $('#dg').datagrid('reload');
                $("#add_form").slideUp();
                return false;
            };
            if (data.id != '000') {
                $("#system_message").slideDown().html(data.message);

            };
        }
    });
});


function Edit(){
    var data = $('#dg').datagrid('getSelected');
    console.log(data);
    if (data){
        $("#add_form").slideDown();     
        $("#add_button").hide();
        $("#update_button").show();
        category_id = data.category_id;
        $("#add_form").find("input[name=category]").val(data.category)
        //$("#add_form").find("input[name=title]").val(data.title);
        $("#add_form").find("input[name=title]").val(data.category);
        $("#add_form").find("textarea[name=content]").val(data.content.replace(/<br>/gi, "\n"));
        $("#preview_image_for_edit").html('<img src="'+data.image_url+'" width="150">');
    }
};

function Add(){
    $("#add_form").slideDown();
    $("#add_button").show();
    $("#update_button").hide();
    $("#add_form").find("input[name=title]").val('');
    $("#add_form").find("textarea[name=content]").val('');
    $("#add_form").find("input[name=category]").val('');
    $("#preview_image_for_edit img").attr('src', '');
    upload_file_name = undefined;
};

function Open(){
var data = $('#dg').datagrid('getSelected');
    if (data){
        var json = {};
        json.category_id = data.category_id;
        var json = jQuery.parseJSON(JSON.stringify(json));

        $.ajax({
            dataType: "json",
            url: 'HandlerCategoryAdm.ashx?action=category_open',
            data: json,
            success: function(data){
                    $('#dg').datagrid('reload');
                    return false;
                }
        });
    }
};

function Close(){
var data = $('#dg').datagrid('getSelected');
    if (data){
        var json = {};
        json.category_id = data.category_id;
        var json = jQuery.parseJSON(JSON.stringify(json));
        $.ajax({
            dataType: "json",
            url: 'HandlerCategoryAdm.ashx?action=category_close',
            data: json,
            success: function(data){
                    $('#dg').datagrid('reload');
                    return false;
                }
        });
        
    }
};

function Delete() {
    if (confirm("確定要永久刪除此筆資料嗎?")) {
        var data = $('#dg').datagrid('getSelected');
        if (data) {
            var json = {};
            json.category_id = data.category_id;
            var json = jQuery.parseJSON(JSON.stringify(json));

            $.ajax({
                dataType: "json",
                url: 'HandlerCategoryAdm.ashx?action=category_delete',
                data: json,
                success: function (data) {
                    $('#dg').datagrid('reload');
                    return false;
                }
            });

        }
    }
};

function format_imageproduct(val, row) {
    return '<img src="' + row.image_url + '" width="150">';
};

function formatStatus(val, row) {
    if (val == 'Y') {
        return '<img src="./ScriptsJQueryEasyUI/themes/icons/active.png"> 啟用';
    } else {
        return '<img src="./ScriptsJQueryEasyUI/themes/icons/deactive.png"> 關閉';
    }
};