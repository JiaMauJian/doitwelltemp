﻿// textarea 存取
// 存 -> X.replace(/\n/g, "<br>")
// 取 -> X.replace(/<br>/gi, "\n")

function Add(){
	$("#product_form").slideDown();
	$("#add_button").show();
	$("#update_button").hide();
};
function Edit(){
	$("#product_form").slideDown();
	$("#add_button").hide();
	$("#update_button").show();

	var data = $('#dg').datagrid('getSelected');

	console.log(data);

	if(data){
	    $("#product_form").find("input[name=prod_id]").val(data.prod_id);
	    $("#product_form").find("input[name=width]").val(data.width);
	    $("#product_form").find("input[name=height]").val(data.height);
	    $("#product_form").find("input[name=bleed_width]").val(data.bleed_width);
	    $("#product_form").find("input[name=bleed_height]").val(data.bleed_height);	    
	    $("#product_form").find("input[name=pages]").val(data.pages);
	    $("#product_form").find("textarea[name=spec]").val(data.spec.replace(/<br>/gi, "\n"));
	    $("#product_form").find("input[name=discount]").val(data.discount);
	    $("#product_form").find("input[name=price]").val(data.price);
	    $("#product_form").find("input[name=default_amount]").val(data.default_amount);
	}
	
	
};
function Open(){
var data = $('#dg').datagrid('getSelected');
	if (data){
		var json = {};
		json.prod_id = data.prod_id;
		var json = jQuery.parseJSON(JSON.stringify(json));
		
		$.ajax({
			dataType: "json",
			url: 'HandlerProductAdm.ashx?action=product_open',
			data: json,
			success: function(data){					
					$('#dg').datagrid('reload');
					return false;
				}
		});
	}
};

function Close(){
var data = $('#dg').datagrid('getSelected');
	if (data){
		var json = {};
		json.prod_id = data.prod_id;
		var json = jQuery.parseJSON(JSON.stringify(json));
		
		$.ajax({
			dataType: "json",
			url: 'HandlerProductAdm.ashx?action=product_close',
			data: json,
			success: function(data){					
					$('#dg').datagrid('reload');
					return false;
				}
		});
	}
};

function Delete() {
	if (confirm("確定要永久刪除嗎?")) {
		var data = $('#dg').datagrid('getSelected');
		if (data) {
			var json = {};
			json.prod_id = data.prod_id;
			var json = jQuery.parseJSON(JSON.stringify(json));

			$.ajax({
				dataType: "json",
				url: 'HandlerProductAdm.ashx?action=product_delete',
				data: json,
				success: function (data) {					
					$('#dg').datagrid('reload');
					return false;
				}
			});

		}
	}
};

$("#add_button").click(function(){
    var json = {};
    json.category = $("#category_name").html();
    json.width = $("#product_form").find("input[name=width]").val();
    json.height = $("#product_form").find("input[name=height]").val();
    json.bleed_width = $("#product_form").find("input[name=bleed_width]").val();
    json.bleed_height = $("#product_form").find("input[name=bleed_height]").val();
    json.pages = $("#product_form").find("input[name=pages]").val();
    json.spec = $("#product_form").find("textarea[name=spec]").val().replace(/\n/g, "<br>");
    json.discount = $("#product_form").find("input[name=discount]").val();
    json.price = $("#product_form").find("input[name=price]").val();
    json.default_amount = $("#product_form").find("input[name=default_amount]").val();
	var json = jQuery.parseJSON(JSON.stringify(json));
	
	$.ajax({
		dataType: "json",
		url: 'HandlerProductAdm.ashx?action=product_add',
		data: json,
		success: function(data){
			if(data.id=='000'){				
				$('#dg').datagrid('reload');
				$("#product_form").slideUp();      
				return false;
			};
			if(data.id != '000'){
			    $("#system_message2").slideDown().html(data.message);
			};
		}
	});
});

$("#update_button").click(function(){
    var json = {};
    json.prod_id = $("#product_form").find("input[name=prod_id]").val();
    json.category = $("#category_name").html();
    json.width = $("#product_form").find("input[name=width]").val();
    json.height = $("#product_form").find("input[name=height]").val();
    json.bleed_width = $("#product_form").find("input[name=bleed_width]").val();
    json.bleed_height = $("#product_form").find("input[name=bleed_height]").val();
    json.pages = $("#product_form").find("input[name=pages]").val();
    json.spec = $("#product_form").find("textarea[name=spec]").val().replace(/\n/g, "<br>");
    json.discount = $("#product_form").find("input[name=discount]").val();
    json.price = $("#product_form").find("input[name=price]").val();
    json.default_amount = $("#product_form").find("input[name=default_amount]").val();
	var json = jQuery.parseJSON(JSON.stringify(json));
	
	$.ajax({
		dataType: "json",
		url: 'HandlerProductAdm.ashx?action=product_update',
		data: json,
		success: function(data){
			if(data.id=='000'){				
				$('#dg').datagrid('reload');
				$("#product_form").slideUp();      
				return false;
			};
			if(data.id != '000'){
			    $("#system_message2").slideDown().html(data.message);
			};
		}
	});
});
function formatStatus(val, row) {
    if (val == 'Y') {
        return '<img src="./ScriptsJQueryEasyUI/themes/icons/active.png"> 啟用';
    } else {
        return '<img src="./ScriptsJQueryEasyUI/themes/icons/deactive.png"> 關閉';
    }
};

function doSearch() {
	$('#dg').datagrid('load', {
		search_field: $('#query_field').val(),
		search_keyword: $('#keyword').val()
	});
};

function OpenContent() {
    $.ajax({
        url: 'HandlerCategoryAdm.ashx?action=open_content&category=' + $("#category_name").html(),
        success: function (data) {
            alert("內容已開啟");
            location.reload();
            return false;
        }
    });
};

function CloseContent() {    
    $.ajax({        
        url: 'HandlerCategoryAdm.ashx?action=close_content&category=' + $("#category_name").html(),        
        success: function (data) {
            alert("內容已關閉");
            location.reload();
            return false;
        }
    });
};