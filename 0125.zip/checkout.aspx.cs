using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

public partial class checkout : System.Web.UI.Page
{
    public string strHtml;
    public string session_user_name;
    public string category_name;
    public string jsonCheckOut;

    protected void Page_Load(object sender, EventArgs e)
    {
        string order_master_id = Request.QueryString["order_id"];

        DataTable dt;
        dt = ComSQL.OrderFinish_Query(order_master_id);

        if (dt.Rows.Count == 0)
        {
            // status�Nincar��^open
            ComSQL.OrderDetail_UpdateInCarStatus(order_master_id);
            jsonCheckOut = JsonConvert.SerializeObject("");            
            return;
        }

        dynamic jsonUser = new JObject();
        jsonUser.Add("order_master_id", dt.Rows[0]["order_master_id"].ToString());
        jsonUser.Add("receiver_name", dt.Rows[0]["receiver_name"].ToString());
        jsonUser.Add("telephone", dt.Rows[0]["telephone"].ToString());
        jsonUser.Add("mobile", dt.Rows[0]["mobile"].ToString());
        jsonUser.Add("email", dt.Rows[0]["email"].ToString());
        jsonUser.Add("zipcode", dt.Rows[0]["zipcode"].ToString());
        jsonUser.Add("city", dt.Rows[0]["city"].ToString());
        jsonUser.Add("locality", dt.Rows[0]["locality"].ToString());
        jsonUser.Add("address", dt.Rows[0]["address"].ToString());
        jsonUser.Add("discount", dt.Rows[0]["discount"].ToString());
        jsonUser.Add("order_detail_list", new JArray());

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            string make_type = dt.Rows[i]["make_type"].ToString();
            string painter_status = dt.Rows[i]["painter_status"].ToString();

            if ((make_type == "painter" && painter_status == "finish") ||
                (make_type == "user_editor" && painter_status == "complete") ||
                (make_type == "boss_editor" && painter_status == "complete"))
            {
                var jsonOrderDetails = new JObject();
                jsonOrderDetails.Add("order_detail_id", dt.Rows[i]["order_detail_id"].ToString());
                jsonOrderDetails.Add("product_type", dt.Rows[i]["product_type"].ToString());
                jsonOrderDetails.Add("product_spec", dt.Rows[i]["product_spec"].ToString());
                jsonOrderDetails.Add("width", dt.Rows[i]["width"].ToString());
                jsonOrderDetails.Add("height", dt.Rows[i]["height"].ToString());
                jsonOrderDetails.Add("bleed_width", dt.Rows[i]["bleed_width"].ToString());
                jsonOrderDetails.Add("bleed_height", dt.Rows[i]["bleed_height"].ToString());
                jsonOrderDetails.Add("pages", dt.Rows[i]["pages"].ToString());
                jsonOrderDetails.Add("product_amount", dt.Rows[i]["product_amount"].ToString());
                jsonOrderDetails.Add("product_price", dt.Rows[i]["product_price"].ToString());
                jsonOrderDetails.Add("product_discount", dt.Rows[i]["product_discount"].ToString());
                jsonOrderDetails.Add("note", dt.Rows[i]["note"].ToString().Replace("\n", "</br>").Replace("\r\n", "</br>"));
                jsonOrderDetails.Add("make_type", dt.Rows[i]["make_type"].ToString());
                jsonOrderDetails.Add("ckfinder_path", dt.Rows[i]["ckfinder_path"].ToString());

                string default_cover = string.Empty;
                if (jsonOrderDetails["make_type"].ToString() == "painter")
                {
                    string painter_cover = dt.Rows[i]["painter_cover"].ToString();                    
                    if (painter_cover.Length > 0)
                        jsonOrderDetails.Add("painter_cover", painter_cover);
                    else
                        jsonOrderDetails.Add("painter_cover", default_cover);
                }
                else if (jsonOrderDetails["make_type"].ToString() == "user_editor")
                {
                    default_cover = "http://140.116.86.160:2688/Images/user_edit.PNG";

                    string path = jsonOrderDetails["ckfinder_path"].ToString();
                    path = "d:\\doitwell02" + path.Replace("/", "\\");
                    string[] pic_paths = Directory.GetFiles(path);
                    if (pic_paths.Length > 0)
                        default_cover = "http://140.116.86.160" + jsonOrderDetails["ckfinder_path"].ToString() + "/" + Path.GetFileName(pic_paths[0]);

                    jsonOrderDetails.Add("painter_cover", default_cover);
                }
                else if (jsonOrderDetails["make_type"].ToString() == "boss_editor")
                {
                    string path = jsonOrderDetails["ckfinder_path"].ToString();
                    path = "d:\\doitwell02" + path.Replace("/", "\\");
                    string[] pic_paths = Directory.GetFiles(path);
                    if (pic_paths.Length > 0)
                        default_cover = "http://140.116.86.160" + jsonOrderDetails["ckfinder_path"].ToString() + "/" + Path.GetFileName(pic_paths[0]);
                    default_cover = "http://140.116.86.160:2688/Images/boss_edit.PNG";
                }                

                ComSQL.OederDetail_UpdatePainterCover(jsonOrderDetails["order_detail_id"].ToString(), jsonOrderDetails["painter_cover"].ToString());

                jsonOrderDetails.Add("painter_id", dt.Rows[i]["painter_id"].ToString());

                jsonUser["order_detail_list"].Add(jsonOrderDetails);
            }            
        }

        jsonCheckOut = JsonConvert.SerializeObject(jsonUser);
    }
}