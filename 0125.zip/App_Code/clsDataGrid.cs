﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for clsDataGrid
/// </summary>
public class clsDataGrid
{
    public string total { get; set; }
    public DataTable rows { get; set; }
}