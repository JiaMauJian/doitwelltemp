﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsPainter
/// </summary>
//public class clsPainter
//{
//    public string book_id { get; set; }
//    public string page_id { get; set; }
//    public string session_id { get; set; }
//    public int step_id { get; set; }
//    public string object_type { get; set; }
//    public double object_height { get; set; }
//    public double object_width { get; set; }
//    public double position_top { get; set; }
//    public double position_left { get; set; }
//    public double angle { get; set; }
//    public string fill { get; set; }
//    public string filpX { get; set; }
//    public string flipY { get; set; }
//    public string hasBorders { get; set; }
//    public string hasControls { get; set; }
//    public string hasRotatingPoint { get; set; }
//    public double opacity { get; set; }  
//    public string overlayFill { get; set; }
//    public double scaleX { get; set; }
//    public double scaleY { get; set; }  
//    public string selectable { get; set; } 
//}

public class clsPainter
{
    public string painter_id { get; set; }    
    public string page_id { get; set; }
    public string order_detail_id { get; set; }
    public string user_name { get; set; }
    public string layer_index { get; set; }
    public string object_index { get; set; }
    public string type { get; set; }
    public string top { get; set; }
    public string left { get; set; }
    public string width { get; set; }
    public string height { get; set; }
    public string selectable { get; set; }
    public string opacity { get; set; }
    public string scaleX { get; set; }
    public string scaleY { get; set; }
    public string fill { get; set; }
    public string radius { get; set; }
    public string angle { get; set; }
    public string stroke { get; set; }
    public string strokeWidth { get; set; }
    public string strokeDashArray { get; set; }
    public string filename { get; set; }
    public string action_function { get; set; }
    public string step_name { get; set; }
    public string isdelete { get; set; }
    public string filters_type { get; set; }
    public string filters_val { get; set; }
    public string fontSize { get; set; }
    public string fontFamily { get; set; }
    public string fontText { get; set; }
    public string fontStyle { get; set; }
    public string fontWeight { get; set; }
    public string textDecoration { get; set;}
    public string textShadow { get; set; }
    public string before_mask_image { get; set; }
    public string user_add_pages { get; set; }
}