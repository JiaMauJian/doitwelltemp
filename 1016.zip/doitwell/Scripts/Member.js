var global_user_name;
var order_id;
function setStorage(name, value, expires) {
    var date = new Date();
    var schedule = Math.round((date.setSeconds(date.getSeconds() + expires)) / 1000);
    localStorage.setItem(name, value);
    localStorage.setItem(name + '_time', schedule);
}

function getStorage(name) {
    return localStorage.getItem(name);
}

function clearUserName() {
    localStorage.user_name = '';
    localStorage.before_login_url = '';
    return false;
}

$(document).ready(function () {
    
    $("#system_message").hide();
    $("#system_message").css({ "background-color": "#D462FF", "padding": "5px", "color": "#ffffff", "margin": "5px" });


    $("#submit_button").click(function (data) {
        $("#system_message").hide();

        if ($.trim($("#user_register_form").find("input[name=real_name]").val()) == '') {
            $("#system_message").slideDown().html("請輸入姓名");
            return false;
        };

        if ($.trim($("#user_register_form").find("input[name=user_name]").val()) == '') {
            $("#system_message").slideDown().html("請輸入帳號");
            return false;
        };

        if ($.trim($("#user_register_form").find("input[name=password]").val()) == '') {
            $("#system_message").slideDown().html("請輸入登入密碼");
            return false;
        };
        if ($("input[name=password]").val().length < 6) {
            $("#system_message").slideDown().html("密碼最少6個字元");
            return false;
        };
        if ($.trim($("#user_register_form").find("input[name=confirm_password]").val()) == '') {
            $("#system_message").slideDown().html("請輸入確認密碼");
            return false;
        };
        if ($.trim($("#user_register_form").find("input[name=confirm_password]").val()) !=
            $.trim($("#user_register_form").find("input[name=password]").val())
        ) {
            $("#system_message").slideDown().html("您輸入兩次的密碼不一樣");
            return false;
        };


        /*
        if( $.trim($("#user_register_form").find("select[name=gender]").val()) == '' ){
        $("#system_message").slideDown().html("請選擇您的性別");
        return false;
        };
        
        if( $.trim($("#user_register_form").find("select[name=birthday_year]").val()) == '' ||
        $.trim($("#user_register_form").find("select[name=birthday_month]").val()) == '' ||
        $.trim($("#user_register_form").find("select[name=birthday_day]").val()) == ''
        ){
        $("#system_message").slideDown().html("請選擇您的生日");
        return false;
        };
        
        if( $.trim($("#user_register_form").find("input[name=telephone]").val()) == '' ){
        $("#system_message").slideDown().html("請輸入電話");
        return false;
        };        
        */
        if ($.trim($("#user_register_form").find("input[name=mobile]").val()) == '') {
            $("#system_message").slideDown().html("請輸入手機");
            return false;
        };
        if ($.trim($("#user_register_form").find("input[name=email]").val()) == '') {
            $("#system_message").slideDown().html("請輸入Email");
            return false;
        };
        /*
        if( $.trim($("#user_register_form").find("input[name=address]").val()) == '' ){
        $("#system_message").slideDown().html("請輸入收件地址");
        return false;
        };
        */

        var member_json = {};
        member_json.real_name = $.trim($("#user_register_form").find("input[name=real_name]").val());
        member_json.user_name = $.trim($("#user_register_form").find("input[name=user_name]").val());
        member_json.password = $.trim($("#user_register_form").find("input[name=password]").val());
        member_json.gender = $.trim($("#user_register_form").find("select[name=gender]").val());
        member_json.birthday_year = $.trim($("#user_register_form").find("select[name=birthday_year]").val());
        member_json.birthday_month = $.trim($("#user_register_form").find("select[name=birthday_month]").val());
        member_json.birthday_day = $.trim($("#user_register_form").find("select[name=birthday_day]").val());
        member_json.telephone = $.trim($("#user_register_form").find("input[name=telephone]").val());
        member_json.mobile = $.trim($("#user_register_form").find("input[name=mobile]").val());
        member_json.email = $.trim($("#user_register_form").find("input[name=email]").val());
        member_json.zipcode = $.trim($("#user_register_form").find("input[name=zipcode]").val());
        member_json.city = $.trim($("#user_register_form").find("select[name=city]").val());
        member_json.locality = $.trim($("#user_register_form").find("select[name=locality]").val());
        member_json.address = $.trim($("#user_register_form").find("input[name=address]").val());
        member_json.verify = $.trim($("#user_register_form").find("input[name=verify]").val());

        var member_json = jQuery.parseJSON(JSON.stringify(member_json));
        //console.log(member_json);

        $.ajax({
            dataType: "json",
            url: 'HandlerMember.ashx?action=member_register',
            data: member_json,
            success: function (data) {
                //console.log(data);
                if (data.id == '000') {
                    window.location.href = '/MemberRegisterMessage.aspx';
                };
                if (data.id != '000') {
                    $("#system_message").slideDown().html(data.message);
                };
            }
        });
    });

    $("#login_button").click(function () {
        if ($("input[name='user_name']").val() == "" || $("input[name='password']").val() == "") {
            $("#system_message").slideDown().html("請輸入登入帳號及密碼");
            return false;
        } else {
            var member_json = {};
            member_json.user_name = $.trim($("#user_login_form").find("input[name=user_name]").val());
            member_json.password = $.trim($("#user_login_form").find("input[name=password]").val());
            var member_json = jQuery.parseJSON(JSON.stringify(member_json));
            //console.log(member_json);

            $.ajax({
                dataType: "json",
                url: 'HandlerMember.ashx?action=member_login',
                data: member_json,
                success: function (data) {
                    //console.log(data);
                    if (data.id == '000') {
                        setStorage('user_id', data.message, 31536000);
                        setStorage('user_name', member_json.user_name, 31536000);
                        if (getStorage('before_login_url') != null && getStorage('before_login_url') != '')
                            window.location.href = getStorage('before_login_url');
                        else
                            window.location.href = 'home.aspx';
                    };
                    if (data.id != '000') {
                        $("#system_message").slideDown().html(data.message);
                    };
                }
            });
        }
    });

    $("#send_forgot_button").click(function () {
        if ($("input[name='email']").val() == "") {
            $("#system_message").slideDown().html("請輸入Email");
            return false;
        } else {
            var member_json = {};
            member_json.email = $.trim($("input[name=email]").val());
            var member_json = jQuery.parseJSON(JSON.stringify(member_json));
            //console.log(member_json);

            $.ajax({
                dataType: "json",
                url: 'HandlerMember.ashx?action=member_forgot',
                data: member_json,
                success: function (data) {
                    //console.log(data);
                    if (data.id == '000') {
                        window.location.href = 'MemberForgotSent.aspx';
                    };
                    if (data.id != '000') {
                        $("#system_message").slideDown().html(data.message);
                    };
                }
            });
        }
    });


    $("#update_button").click(function (data) {
        //alert('123');
        $("#system_message").hide();

        if ($.trim($("#update_member_info_form").find("input[name=real_name]").val()) == '') {
            $("#system_message").slideDown().html("請輸入姓名");
            return false;
        };

        if ($.trim($("#update_member_info_form").find("input[name=password]").val()) == '') {
            $("#system_message").slideDown().html("請輸入登入密碼");
            return false;
        };
        if ($("input[name=password]").val().length < 6) {
            $("#system_message").slideDown().html("密碼最少6個字元");
            return false;
        };
        if ($.trim($("#update_member_info_form").find("input[name=confirm_password]").val()) == '') {
            $("#system_message").slideDown().html("請輸入確認密碼");
            return false;
        };
        if ($.trim($("#update_member_info_form").find("input[name=confirm_password]").val()) !=
            $.trim($("#update_member_info_form").find("input[name=password]").val())
        ) {
            $("#system_message").slideDown().html("您輸入兩次的密碼不一樣");
            return false;
        };

        if ($.trim($("#update_member_info_form").find("input[name=mobile]").val()) == '') {
            $("#system_message").slideDown().html("請輸入手機");
            return false;
        };
        if ($.trim($("#update_member_info_form").find("input[name=email]").val()) == '') {
            $("#system_message").slideDown().html("請輸入Email");
            return false;
        };

        var member_json = {};
        member_json.real_name = $.trim($("#update_member_info_form").find("input[name=real_name]").val());
        member_json.user_name = global_user_name;
        member_json.password = $.trim($("#update_member_info_form").find("input[name=password]").val());
        member_json.gender = $.trim($("#update_member_info_form").find("select[name=gender]").val());
        member_json.birthday_year = $.trim($("#update_member_info_form").find("select[name=birthday_year]").val());
        member_json.birthday_month = $.trim($("#update_member_info_form").find("select[name=birthday_month]").val());
        member_json.birthday_day = $.trim($("#update_member_info_form").find("select[name=birthday_day]").val());
        member_json.telephone = $.trim($("#update_member_info_form").find("input[name=telephone]").val());
        member_json.mobile = $.trim($("#update_member_info_form").find("input[name=mobile]").val());
        member_json.email = $.trim($("#update_member_info_form").find("input[name=email]").val());
        member_json.zipcode = $.trim($("#update_member_info_form").find("input[name=zipcode]").val());
        member_json.city = $.trim($("#update_member_info_form").find("select[name=city]").val());
        member_json.locality = $.trim($("#update_member_info_form").find("select[name=locality]").val());
        member_json.address = $.trim($("#update_member_info_form").find("input[name=address]").val());
        member_json.verify = $.trim($("#update_member_info_form").find("input[name=verify]").val());

        var member_json = jQuery.parseJSON(JSON.stringify(member_json));
        //console.log(member_json);

        $.ajax({
            dataType: "json",
            url: 'HandlerMember.ashx?action=member_update',
            data: member_json,
            success: function (data) {
                //console.log(data);
                if (data.id == '000') {
                    alert(data.message);
                    return false;
                };
                if (data.id != '000') {
                    $("#system_message").slideDown().html(data.message);
                };
            }
        });
    });
});

function goMemberUpdate() {

    $("#update_button").button().css({ "font-size": "12px" });
    var member_json = {};
    member_json.user_name = getStorage('user_name');
    var member_json = jQuery.parseJSON(JSON.stringify(member_json));
    //console.log(member_json);

    $.ajax({
        dataType: "json",
        url: 'HandlerMember.ashx?action=get_member_info',
        data: member_json,
        success: function (data) {
            init_address();
            console.log(data);
            $("#update_member_info_form").find("input[name=real_name]").val(data.real_name);
            $("#user_name").html(data.user_name);
            global_user_name = data.user_name;
            $("#update_member_info_form").find("input[name=password]").val(data.password);
            $("#update_member_info_form").find("input[name=confirm_password]").val(data.password);
            $("#update_member_info_form").find("select[name=gender]").val(data.gender);
            $("#update_member_info_form").find("select[name=birthday_year]").val(data.birthday_year);
            $("#update_member_info_form").find("select[name=birthday_month]").val(data.birthday_month);
            $("#update_member_info_form").find("select[name=birthday_day]").val(data.birthday_day);
            $("#update_member_info_form").find("input[name=telephone]").val(data.telephone);
            $("#update_member_info_form").find("input[name=mobile]").val(data.mobile);
            $("#update_member_info_form").find("input[name=email]").val(data.email);
            $("#update_member_info_form").find("input[name=zipcode]").val(data.zipcode);
            $("#update_member_info_form").find("select[name=city]").val(data.city);
            $("#update_member_info_form").find("select[name=city]").trigger("change");
            $("#update_member_info_form").find("select[name=locality]").val(data.locality);
            $("#update_member_info_form").find("select[name=locality]").trigger("change");
            $("#update_member_info_form").find("input[name=address]").val(data.address);
        }
    });

};

function goOrder() {

    $.ajax({
        dataType: "json",
        url: 'HandlerOrder.ashx?action=member_order_detail_query&user_id=' + getStorage('user_id'),
        success: function (data) {
            console.log(data);

            var order_total_price = 0;
            var order_total_price_after_discount = 0;

            $('#order_information_table tr:gt(0)').remove();

            var stickyCnt = 1;

            $.each(data.rows, function (k, v) {
                var note = '';
                if (v.note != null)
                    note = v.note;

                var stauts = '';
                var od_preview = '';

                if (v.status1 == 'inproc') {
                    stauts = '<span style="background-color:Lime;">尚未付款<br>待製作</span>';
                } else if (v.status1 == 'payment') {
                    stauts = '<span style="background-color:Yellow;">已付款<br>製作中</span>';
                } else if (v.status1 == 'cancel') {
                    stauts = '<span style="background-color:Magenta;color:White;">取消</span>';
                } else if (v.status1 == 'close') {
                    stauts = '<span style="background-color:Silver;">已結單</span>';
                } else if (v.status1 == 'deliver') {
                    stauts = '<span style="background-color:Blue;color:White;">完成製作<br>交貨中</span>';
                } else if (v.status1 == 'return') {
                    stauts = '<span style="background-color:Red;color:White;">退件</span>';
                }

                if (v.painter_status == 'close' && v.make_type == 'painter') {
                    od_preview = '<td class="for_center" ><button class="open_painter" type="button" onclick="javascript: window.open(\'preview.html?painter_id=' + v.painter_id + '&order_detail_id=' + v.order_detail_id + '\', \'_blank\')">預覽</button></td>';
                } else if (v.painter_status == 'complete') {
                    od_preview = '<td class="for_center" ><button class="open_painter" type="button" onclick="javascript: window.open(\'preview.html?painter_id=' + v.painter_id + '&order_detail_id=' + v.order_detail_id + '\', \'_blank\')">預覽</button></td>';
                } else {
                    od_preview = '<td class="for_center"></td>';
                }

                var make_type;

                if (v.make_type == 'painter')
                    make_type = '<td class="for_center">線上編輯</td>';
                else if (v.make_type == 'user_editor')
                    make_type = '<td class="for_center">自編上傳</td>';
                else if (v.make_type == 'boss_editor')
                    make_type = '<td class="for_center">委託編輯</td>';

                var append_item = '<tr>' +
                '<td class="for_order_detail_id">' + v.confirm_order_detail_id + '</td>' +
                '<td class="for_center"><a href="' + v.painter_cover + '" class="preview"><img src=' + v.painter_cover + ' width=60></img></a></td>' +
                //'<td class="for_center"><a href="/doitwell02/upload/ads_images/product/13024.jpg" class="preview"><img src="/doitwell02/upload/ads_images/product/13024.jpg" width=30%></img></a></td>' +
		        '<td class="for_center">' + v.product_type + '</td>' +
                '<td class="for_center">' + v.width + ' x ' + v.height + '</td>' +
                '<td class="for_center">' + v.product_spec + '</td>' +
                '<td class="for_center">' + v.pages + '</td>' +
                '<td class="for_center">' + v.product_price + '</td>' +
                '<td class="for_center">' + note + '</td>' +
                make_type +
                '<td class="for_center">' + stauts + '</td>' +
                od_preview +
                //            '<td class="for_center"><button class="order_cancel" type="button" onclick="cancel_order_detail(' + v.order_detail_id + ')">取消</button></td>'
                '</tr>';
                //console.log(append_item);
                $("#order_information_table tr:last").after(append_item);
                order_total_price += parseInt(v.product_price);
                order_total_price_after_discount += parseInt(v.product_price);

                $(".order_cancel").button().css({ 'font-size': '10px' });
            });

            $("#order_total_price").html(order_total_price);
            $("#order_total_price").currency({ region: 'TWD', decimals: 0 });
            $("#order_total_price_after_discount").html(order_total_price_after_discount);
            $("#order_total_price_after_discount").currency({ region: 'TWD', decimals: 0 });

            if (order_total_price > 0) {
                $("#show_price").show();
            } else {
                $("#show_price").hide();
            }

            imagePreview();

            $(".open_painter").button().css({ 'font-size': '10px' });
        }
    });
};

function cancel_order_detail(id) {
    if (confirm('確定取消此訂單嗎?')) {
        $.ajax({
            url: 'HandlerOrder.ashx?action=member_order_detail_cancel&order_detail_id=' + id,
            success: function (data) {
                data = JSON.parse(data);
                if (data.id == '000') {
                    $("#order_query").trigger('click');
                };
                if (data.id != '000') {
                    $("#system_message").slideDown().html(data.message);
                };
            }
        });
    }   
};
function open_painter(order_id, order_detail_id, painter_id){
	myWindow=window.open('painter.html?order_id=' + order_id + '&order_detail_id='+order_detail_id+'&painter_id='+painter_id+'&ref=MemberCenter', 'DoItWell Painter','width=1250,height=740,fullscreen=yes,left=0,top=0');
	myWindow.focus();
	return false;
};

function checkout(){
    window.location.href = 'checkout.aspx?user_id=' + getStorage('user_id') + '&order_id=' + order_id + '&make_type=painter';
};

function open_iframe(url) {
    $('#block').fadeIn();
    $('#iframe').attr('src', url);
    $('#container').fadeIn();
};

function close_iframe() {
    $('#block').fadeOut();
    $('#container').fadeOut();
};

function open_ckfinder(user_name, make_type, porduct_type, order_master_id) {

    var create_ed_json = {};
    create_ed_json.order_id = order_master_id;
    create_ed_json.user_name = user_name;
    create_ed_json.category_name = porduct_type;
    create_ed_json.CKBaseURL = '~/upload/' + make_type + '/';
    create_ed_json.CKBaseDIR = 'd:\\doitwell02\\upload\\' + make_type + '\\';    
    $.ajax({
        type: "POST",
        dataType: "json",
        url: 'HandlerPainter.ashx?action=create_' + make_type + '_folder',
        data: JSON.stringify(create_ed_json),
        success: function (data) {
            if (data.id == '000') {
                open_iframe('./upload.html?make_type=' + make_type + '&order_id=' + order_master_id + '&checkout=true');
            }
            else
                alert(data.message);
        }
    }); 
};

var goEditCount = 0;
var goCheckCount = 0;

function goShopCar() {

    goEditCount = 0;
    goCheckCount = 0;

    $.ajax({
        dataType: "json",
        url: 'HandlerOrder.ashx?action=member_shopcar_detail_query&user_id=' + getStorage('user_id'),
        success: function (data) {
            console.log(data);
            $('#works_table tr:gt(0)').remove();

            $.each(data.rows, function (k, v) {

                var note = '';
                if (v.note != null)
                    note = v.note;

                var make_type = '';
                if (v.make_type == 'painter')
                    make_type = '<td class="for_painter_editor">線上編輯</td>';
                else if (v.make_type == 'user_editor')
                    make_type = '<td class="for_user_editor">自編上傳</td>';
                else if (v.make_type == 'boss_editor')
                    make_type = '<td class="for_boss_editor">委託編輯</td>';

                var append_item = '<tr>' +
                make_type +
                '<td class="for_center"><a href="' + v.painter_cover + '" class="preview"><img src=' + v.painter_cover + ' width=60></img></a></td>' +
		        '<td class="for_center" >' + v.product_type + '</td>' +
                '<td class="for_center" >' + v.product_spec + '</td>' +
                '<td class="for_center" >' + v.pages + '</td>' +
                '<td class="for_center" >' + v.product_amount + '</td>' +
                '<td class="for_center" >' + v.product_price + '</td>' +
                '<td class="for_center" >' + note + '</td>';

                if (v.make_type == 'painter') {

                    if (v.painter_status == 'open' || v.painter_status == 'edit') {
                        append_item += '<td class="for_center" ><button class="open_painter" type="button" onclick="open_painter(\'' + v.order_master_id + '\',\'' + v.order_detail_id + '\',\'' + v.painter_id + '\');">編輯</button></td>';
                    }
                    else {
                        append_item += '<td class="for_center" ><button class="open_painter" type="button" onclick="javascript: window.open(\'preview.html?painter_id=' + v.painter_id + '\', \'_blank\')">預覽</button></td>';
                        goCheckCount++;
                    }

                    append_item += '</tr>';

                    if (v.painter_status == 'open' || v.painter_status == 'edit') {
                        goEditCount++;
                        $("#works_table tr:last").after(append_item);
                    }
                    else if (v.painter_status == 'finish') {
                        order_id = v.order_master_id;
                        $("#works_table tr:last").after(append_item);
                    }
                    else if (v.painter_status == 'close') {
                        $("#works_table tr:last").after(append_item);
                    }
                }
                else {

                    if (v.painter_status == 'complete') {
                        append_item += '<td class="for_center" ><button class="open_painter" type="button" onclick="javascript: window.open(\'preview.html?painter_id=' + v.painter_id + '&order_detail_id=' + v.order_detail_id + '\', \'_blank\')">預覽</button></td>';
                        append_item += '</tr>';
                    } else {
                        append_item += '<td class="for_center" ><button class="open_painter" type="button" onclick="open_ckfinder(\'' + getStorage('user_name') + '\',\'' + v.make_type + '\',\'' + v.product_type + '\',\'' + v.order_master_id + '\');">上傳</button></td>';
                        append_item += '</tr>';
                        goCheckCount++;
                    }

                    $("#works_table tr:last").after(append_item);
                }
            });

            $(".open_painter").button().css({ 'font-size': '10px' });

            if (goEditCount > 0)
                $("#goEdit").html("您有 " + goEditCount + " 項作品尚在編輯，前往作品清單，開始製作!");

            imagePreview();

            if (goCheckCount > 0)
                $("#checkout_button").show();
            else
                $("#checkout_button").hide();
        }
    }); 
};

function goMyWokrs() {
    $("#my_works").find("div").remove();

    $.ajaxSetup({ async: false });

    $.ajax({
        url: 'HandlerOrder.ashx?action=member_category_query',
        success: function (data) {
            data = JSON.parse(data);
            $.each(data, function (k, v) {

                $.getJSON('HandlerOrder.ashx?action=member_painter_cover&category=' + v.category + '&user_id=' + getStorage('user_id'), function (data1) {

                    console.log(data1);

                    if (data1.length > 0)
                        $("#my_works").append('<div style="clear:both">' + v.category + '</div><div id="gallery' + v.category_id + '"></div>');

                    $.each(data1, function (k1, v1) {
                        $("#gallery" + v.category_id).append('<a href="javascript: window.open(\'preview.html?painter_id=' + v1.painter_id + '&order_detail_id=' + v1.order_detail_id + '\', \'_blank\')"><div class="figure"><div class="photo"></div><img src="' + v1.painter_cover + '" width="150" height="150" /></div></a>');
                    });
                });

            });
        }
    });

    $.ajaxSetup({ async: true });
};

function delete_order_detail(id) {
    if (confirm('確定刪除此訂單嗎?')) {
        $.ajax({
            url: 'HandlerOrder.ashx?action=member_order_detail_delete&order_detail_id=' + id,
            success: function (data) {
                data = JSON.parse(data);
                if (data.id == '000') {
                    $("#shop_car").trigger('click');
                };
                if (data.id != '000') {
                    $("#system_message").slideDown().html(data.message);
                };
            }
        });
    }    
};