﻿$("#btnSearch").button();

Date.prototype.format_date = function () {
    var yyyy = this.getFullYear().toString();
    var mm = (this.getMonth()+1).toString();
    var dd = this.getDate().toString();
    var hh = this.getHours();
    var ii = this.getMinutes();
    var ss = this.getSeconds();
    return yyyy +'-'+ (mm[1]?mm:"0"+mm[0]) +'-'+ (dd[1]?dd:"0"+dd[0]) +' '+ hh +':'+ii+':'+ss;
};

$("#update_button").button().css({"font-size":"12px"});
function Edit(){
var data = $('#dg').datagrid('getSelected');
	if (data){
		init_address();
		console.log(data);
		$("#order_form").slideDown();
		$("#order_form").find("input[name=order_id]").val(data.order_id);
		$("#order_form").find("input[name=confirm_order_id]").val(data.confirm_order_id);
		$("#order_form").find("input[name=user_name]").val(data.user_name);
		$("#order_form").find("input[name=real_name]").val(data.real_name);
		$("#order_form").find("input[name=receiver_name]").val(data.receiver_name);
		$("#order_form").find("input[name=mobile]").val(data.mobile);
		$("#order_form").find("input[name=zipcode]").val(data.zipcode);
		$("#order_form").find("select[name=city]").val(data.city);
		$("#order_form").find("select[name=city]").trigger("change");
		$("#order_form").find("select[name=locality]").val(data.locality);
		$("#order_form").find("input[name=address]").val(data.address);
		$("#order_form").find("select[name=locality]").trigger("change");
		$("#order_form").find("select[name=payment_type]").val(data.payment_type);
		$("#order_form").find("input[name=bank_account]").val(data.bank_account);
		$("#order_form").find("input[name=remit_total_money]").val(data.remit_total_money);
		$("#order_form").find("input[name=order_total_money]").val(data.order_total_money);
		$("#order_form").find("input[name=discount]").val(data.discount);
		$("#order_form").find("input[name=after_discount_price]").val(data.order_total_money * data.discount);
		$("#order_form").find("select[name=use_coupon]").val(data.use_coupon);
		$("#order_form").find("input[name=coupon_discount]").val(data.coupon_discount);
		$("#order_form").find("input[name=after_coupon_discount_price]").val(data.order_total_money * data.coupon_discount);
		$("#order_form").find("select[name=status]").val(data.status);
		$("#order_form").find("textarea[name=note]").val(data.note);
		$("#open_time").html(data.open_time);
		$("#close_time").html(data.close_time);
		$("#cancel_time").html(data.cancel_time);
		$("#payment_time").html(data.payment_time);
		$("#deliver_time").html(data.deliver_time);
		$("#return_time").html(data.return_time);
	}
};

function Open(){
var data = $('#dg').datagrid('getSelected');
	if (data){
		var json = {};
		json.order_id = data.order_id;
		var json = jQuery.parseJSON(JSON.stringify(json));
		console.log(json);
		
		$.ajax({
			dataType: "json",
			url: 'HandlerOrderAdm.ashx?action=order_open',
			data: json,
			success: function(data){
					console.log(data);
					$("#system_message").slideDown().html(data.message);
					$('#dg').datagrid('reload');
					return false;
				}
		});
	}
};

function Close(){
var data = $('#dg').datagrid('getSelected');
	if (data){
		var json = {};
		json.order_id = data.order_id;
		var json = jQuery.parseJSON(JSON.stringify(json));
		console.log(json);
		
		$.ajax({
			dataType: "json",
			url: 'HandlerOrderAdm.ashx?action=order_close',
			data: json,
			success: function(data){
					console.log(data);
					$("#system_message").slideDown().html(data.message);
					$('#dg').datagrid('reload');
					return false;
				}
		});
	}
};


function Delete() {
	if (confirm("確定要永久刪除此訂單嗎?")) {
		var data = $('#dg').datagrid('getSelected');
		if (data) {
			var json = {};
			json.order_id = data.order_id;
			var json = jQuery.parseJSON(JSON.stringify(json));
			console.log(json);

			$.ajax({
				dataType: "json",
				url: 'HandlerOrderAdm.ashx?action=order_delete',
				data: json,
				success: function (data) {
					console.log(data);
					$("#system_message").slideDown().html(data.message);
					$('#dg').datagrid('reload');
					return false;
				}
			});

		}
	}
};

$("#update_button").click(function(){
    var json = {};
    json.order_id = $("#order_form").find("input[name=order_id]").val();
	json.user_name = $("#order_form").find("input[name=user_name]").val();
	json.real_name = $("#order_form").find("input[name=real_name]").val();
	json.receiver_name = $("#order_form").find("input[name=receiver_name]").val();
	json.mobile = $("#order_form").find("input[name=mobile]").val();
	json.zipcode = $("#order_form").find("input[name=zipcode]").val();
	json.city = $("#order_form").find("select[name=city]").val();
	json.locality = $("#order_form").find("select[name=locality]").val();
	json.address = $("#order_form").find("input[name=address]").val();
	json.payment_type = $("#order_form").find("select[name=payment_type]").val();
	json.bank_account = $("#order_form").find("input[name=bank_account]").val();
	json.remit_total_money = $("#order_form").find("input[name=remit_total_money]").val();
	json.order_total_money = $("#order_form").find("input[name=order_total_money]").val();
	json.discount = $("#order_form").find("input[name=discount]").val();
	json.use_coupon = $("#order_form").find("select[name=use_coupon]").val();
	json.coupon_discount = $("#order_form").find("input[name=coupon_discount]").val();
	json.status = $("#order_form").find("select[name=status]").val();
	json.note = $("#order_form").find("textarea[name=note]").val();

	var d = new Date();
	if (json.status == 'close')
		json.close_time = d.format_date();
	if (json.status == 'cancel')
		json.cancel_time = d.format_date();
	if (json.status == 'payment')
		json.payment_time = d.format_date();
	if (json.status == 'deliver')
		json.deliver_time = d.format_date();
	if (json.status == 'return')
	    json.return_time = d.format_date();			
	
	var json = jQuery.parseJSON(JSON.stringify(json));
	console.log(json);
	
	$.ajax({
		dataType: "json",
		url: 'HandlerOrderAdm.ashx?action=order_update',
		data: json,
		success: function(data){
			console.log(data);
			if(data.id=='000'){
				alert(data.message);
				$('#dg').datagrid('reload');
				$("#order_form").slideUp();      
				return false;
			};
			if(data.id != '000'){
				$("#system_message").slideDown().html(data.message);
			   
			};
		}
	});
});
	
function doSearch() {
	$('#dg').datagrid('load', {
		search_field: $('#query_field').val(),
		search_keyword: $('#keyword').val()
	});
};

function format_after_discount_price(val, row) {
    return row.order_total_money * row.discount;
};

function format_after_coupon_discount_price(val, row) {
    return row.order_total_money * row.coupon_discount;
};

function formatDiscount(val, row) {
    aa = row;
    if (val < 1) {
        return '<span style="color:red;">' + val + '</span>';
    } else {
        return val;
    }
};

function format_use_coupon(val, row) {
	if(row.use_coupon == 'Y')
		return '是';
	else
		return '否';
};
function format_status(val, row) {
	if(row.status == 'open')
	    return '新單頭';
	if (row.status == 'delete')
	    return '刪除';
	if(row.status == 'close')
	    return '<span style="background-color:Silver;">已結單</span>';
	if (row.status == 'cancel')
	    return '<span style="background-color:Magenta;color:White;">取消</span>';
	if (row.status == 'payment')
	    return '<span style="background-color:Yellow;">已付款<br>製作中</span>';
	if (row.status == 'deliver')
	    return '<span style="background-color:Blue;color:White;">完成製作<br>交貨中</span>';		
	if (row.status == 'return')
	    return '<span style="background-color:Red;color:White;">退件</span>';	    
	if (row.status == 'inproc')
	    return '<span style="background-color:Lime;">尚未付款<br>待製作</span>';   
};

function format_make_type(val, row) {
    if (row.make_type == 'painter')
        return '線上編輯';
    if (row.make_type == 'user_editor')
        return '自編上傳';
    if (row.make_type == 'boss_editor')
        return '委託編輯';    
};

function Detail(){
	var data = $('#dg').datagrid('getSelected');
	console.log(data);
	$.getJSON('HandlerOrderAdm.ashx?action=order_detail_query&order_master_id=' + data.order_id, function (data) {
	    if (data) {
	        console.log(data.rows);
	        $("#order_detail_block").show().css({ 'position': 'fixed', 'top': '50%', 'left': '50%' });
	        $("#order_detail_block tr:gt(0)").remove();

	        $.each(data.rows, function (k, v) {

	            var make_type = '';
	            if (v.make_type == 'painter')
	                make_type = '線上編輯';
	            else if (v.make_type == 'user_editor')
	                make_type = '自編上傳';
	            else if (v.make_type == 'boss_editor')
	                make_type = '委託編輯';

	            var painter_status_select = ''
	            if (v.make_type != 'painter') {
	                painter_status_select = '<select id="painter_status_' + v.order_detail_id +
                                            '"><option value="close">製作中</option>' +
                                            '<option value="complete">完成製作</option>' +
                                            '</select>';
	            }
	            else {
	                painter_status_select = '完成製作';
	            }


	            var append_data = '<tr>' +
            '<td id="master_id_' + v.order_detail_id + '" contenteditable="false" style="display:none;">' + v.order_master_id + '</td>' +
			'<td id="detail_id_' + v.order_detail_id + '" contenteditable="false" style="display:none;">' + v.order_detail_id + '</td>' +
			'<td id="detail_type_' + v.order_detail_id + '" contenteditable="false">' + make_type + '</td>' +
            '<td id="detail_type_' + v.order_detail_id + '" contenteditable="false">' + v.product_type + '</td>' +
			'<td id="detail_spec_' + v.order_detail_id + '" contenteditable="false">' + v.product_spec + '</td>' +
			'<td id="detail_pages_' + v.order_detail_id + '" contenteditable="false">' + v.pages + '</td>' +
			'<td id="detail_price_' + v.order_detail_id + '" contenteditable="false">' + v.product_price + '</td>' +
	            //			'<td id="detail_discount_' + v.order_detail_id + '" contenteditable="true"><span style="padding:2px;background-color:#FFFFC2;border:1px dotted #333333;">' + v.product_discount + '</span></td>' +
	            //			'<td contenteditable="true"><span style="padding:2px;background-color:#FFFFC2;border:1px dotted #333333;">' + (v.product_price * v.product_amount) * v.product_discount + '</span></td>' +
			'<td id="detail_note_' + v.order_detail_id + '"><textarea value="" id="note_' + v.order_detail_id + '" rows="2" cols="20" style="width:95%;background-color:LightYellow">' + v.note + '</textarea></td>' +
            '<td id="detail_price_' + v.order_detail_id + '" contenteditable="false">' + painter_status_select + '</td>' +
			'<td><button class="update_detail" type="button" onclick="update_detail(' + v.order_detail_id + ')">更新</button></td>' +
			'</tr>';
	            console.log(append_data);

	            $("#order_detail_block tr:last").after(append_data);

	            $(".update_detail").button().css({ 'font-size': '10px' });
	        });
	    }
	});
};

function update_detail(id){
    var json = {};
    json.order_master_id = $("#master_id_"+id).text();
    json.order_detail_id = $("#detail_id_"+id).text();
//	json.product_type = $("#detail_type_"+id).text();
//	json.product_spec = $("#detail_spec_"+id).text();
//	json.product_amount = $("#detail_amount_"+id+ " span").text();
//	json.product_price = $("#detail_price_"+id+ " span").text();
//	json.product_discount = $("#detail_discount_"+id+ " span").text();
    json.note = $("#note_" + id).val().replace(/\n/g, ';');
    json.painter_status = $("#painter_status_" + id).val();
    console.log(json);
	var json = jQuery.parseJSON(JSON.stringify(json));	
	
	$.ajax({
		dataType: "json",
		url: 'HandlerOrderAdm.ashx?action=order_detail_update',
		data: json,
		success: function(data){
			console.log(data);
			if(data.id=='000'){
				alert(data.message);
				return false;
			};
			if(data.id != '000'){
				$("#system_message").slideDown().html(data.message);
			   
			};
		}
	});
};

