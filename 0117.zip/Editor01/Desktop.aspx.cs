﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Newtonsoft.Json.Linq;

public partial class Desktop : System.Web.UI.Page
{
    public string category_name;
    protected void Page_Load(object sender, EventArgs e)
    {
        GetWorkList();
    }

    private void GetWorkList()
    {
        string order_master_id = Request.QueryString["order_id"];

        DataTable dt;
        dt = ComSQL.OrderDetail_QueryPainter(order_master_id);

        dynamic jWorkList = new JObject();
        jWorkList.order_master_id = order_master_id;
        jWorkList.Add("work_list", new JArray());

        string confirm_order_id = string.Empty;
        string spec = string.Empty;
        string category = string.Empty;
        string p_status_str = string.Empty;
        string p_status = string.Empty;

        for (int i = 0; i < dt.Rows.Count; i++)
        {            
            dynamic jWork = new JObject();
            jWork.order_detail_id = dt.Rows[i]["order_detail_id"].ToString();
            jWork.product_type = dt.Rows[i]["product_type"].ToString();
            jWork.product_spec = dt.Rows[i]["product_spec"].ToString();
            jWork.product_amount = dt.Rows[i]["product_amount"].ToString();
            jWork.product_price = dt.Rows[i]["product_price"].ToString();
            jWork.product_discount = dt.Rows[i]["product_discount"].ToString();
            jWork.width = dt.Rows[i]["width"].ToString();
            jWork.height = dt.Rows[i]["height"].ToString();
            jWork.bleed_width = dt.Rows[i]["bleed_width"].ToString();
            jWork.bleed_height = dt.Rows[i]["bleed_height"].ToString();            
            jWork.pages = dt.Rows[i]["pages"].ToString();
            jWork.note = dt.Rows[i]["note"].ToString();
            jWork.painter_status = dt.Rows[i]["painter_status"].ToString();
            jWork.painter_id = dt.Rows[i]["painter_id"].ToString();
            jWork.confirm_order_detail_id = dt.Rows[i]["confirm_order_detail_id"].ToString();
            jWork.prod_id = dt.Rows[i]["prod_id"].ToString();

            if (jWork.painter_status == "finish")
                p_status_str = "[已完成]";
            else
                p_status_str = "[可編輯]";

            p_status = "\"" + jWork.painter_status + "\"";
            confirm_order_id = jWork.confirm_order_detail_id;
            spec = "\"" + jWork.product_spec.ToString().Replace("<br>", " ") + "_" + (i + 1).ToString() + "\"";
            category = "\"" + jWork.product_type + "\"";
            litWorkList.Text += string.Format("<li style='{3}'><a id='{4}' style='margin-left:5px' href='javascript:editWork({4}, {7}, {8}, {9}, {10}, {11}, {1}, {2}, {5}, {6})'>{12}</a><a style='margin-left:5px' href='javascript:deleteWork()'>[刪除]</a><span style='margin-left:5px;color:white;'>ID: {4} {0}: 寬:{1} 長:{2} (cm)</span></li>", jWork.product_type, jWork.width, jWork.height, "margin:0 5px 0 5px", jWork.order_detail_id, jWork.bleed_width, jWork.bleed_height, jWork.painter_id, confirm_order_id, spec, category, p_status, p_status_str);
        }        
    }
}