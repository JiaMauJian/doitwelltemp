-- --------------------------------------------------------
-- 主機:                           127.0.0.1
-- 服務器版本:                        5.0.51b-community-nt-log - MySQL Community Edition (GPL)
-- 服務器操作系統:                      Win32
-- HeidiSQL 版本:                  8.1.0.4545
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 導出  表 doitwell.ads 結構
DROP TABLE IF EXISTS `ads`;
CREATE TABLE IF NOT EXISTS `ads` (
  `ads_id` int(10) NOT NULL auto_increment,
  `kind` varchar(128) default NULL,
  `content` text NOT NULL,
  `image_url` text,
  `status` varchar(2) NOT NULL default 'Y',
  `content2` text,
  `start_time` varchar(20) default NULL,
  `end_time` varchar(20) default NULL,
  `title` varchar(45) default NULL,
  PRIMARY KEY  (`ads_id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.ads 的資料：27 rows
DELETE FROM `ads`;
/*!40000 ALTER TABLE `ads` DISABLE KEYS */;
INSERT INTO `ads` (`ads_id`, `kind`, `content`, `image_url`, `status`, `content2`, `start_time`, `end_time`, `title`) VALUES
	(22, 'recommend', '♥【L & B wedding】♥ 分享超平價的無框油畫布!!', 'http://verywed.com/forum/expexch/2481236-1.html?from=about', 'Y', NULL, NULL, NULL, NULL),
	(23, 'recommend', '♥【 W & X 】分享無框畫', 'http://verywed.com/forum/expexch/2557566-1.html', 'Y', NULL, NULL, NULL, NULL),
	(24, 'recommend', '♥【無框畫開箱文】', 'http://verywed.com/vwblog/momokids/article/63389', 'Y', NULL, NULL, NULL, NULL),
	(25, 'recommend', '♥【 L&S wedding】 ♥ 開箱文45吋正方型放大無框畫', 'http://www.wretch.cc/blog/lyd3070932ca/1880450', 'Y', NULL, NULL, NULL, NULL),
	(26, 'recommend', '♥【玥の花嫁 ♥ 婚禮小物分享】', 'http://verywed.com/forum/expexch/2379243-1.html', 'Y', NULL, NULL, NULL, NULL),
	(27, 'recommend', '♥【 D & P 分享無框放大畫】', 'http://verywed.com/forum/expexch/2460501-1.html', 'Y', NULL, NULL, NULL, NULL),
	(29, 'recommend', '♥【我們的婚禮全家福無框畫】', 'http://verywed.com/vwblog/s851959/article/68515', 'Y', NULL, NULL, NULL, NULL),
	(30, 'recommend', '♥【我的超時尚無框畫時鐘】', 'http://verywed.com/forum/expexch/2544053-1.html?from=expexch', 'Y', NULL, NULL, NULL, NULL),
	(31, 'recommend', '♥【超愛無框畫。比婚紗公司更精緻】', 'http://verywed.com/forum/expexch/2577185-1.html', 'Y', NULL, NULL, NULL, NULL),
	(32, 'recommend', '♥【我們的幸福全家福無框畫】', 'http://verywed.com/forum/expexch/2577081-1.html', 'Y', NULL, NULL, NULL, NULL),
	(3, 'slider', 'adv03', 'upload/ads_images/slider/adv03.png', 'Y', NULL, '2013-08-01', '2014-08-01', NULL),
	(1, 'slider', 'adv01', 'upload/ads_images/slider/adv01.png', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(2, 'slider', 'adv02', 'upload/ads_images/slider/adv02.png', 'Y', NULL, '2013-08-01', '2014-08-01', NULL),
	(17, 'recommend', '♥【無框畫分享】', 'http://verywed.com/forum/expexch/2553987-1.html', 'Y', NULL, NULL, NULL, NULL),
	(36, 'recommend', '測試跑馬燈最大長度QWERTYUIOPLOKJHGFDSAZXCVBNJMKJUYHTGEDWEDGTHYJUYKIMJYNHGBVED#R$%T$HY&U^J*KIYJUTHGREDWTGYHJUKIYJUTHGRR%T$^Y%&UJYNHTYGRT%$^Y&UJYTHG', '', 'N', NULL, NULL, NULL, NULL),
	(47, 'product', 'custom_prod.aspx', 'upload/ads_images/product/12026.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(48, 'product', 'custom_prod.aspx', 'upload/ads_images/product/12038.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(49, 'product', 'custom_prod.aspx', 'upload/ads_images/product/13024.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(50, 'product', 'custom_prod.aspx', 'upload/ads_images/product/13025.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(43, 'product', 'preview.html?painter_id=1381824099789&order_detail_id=1752', 'upload/ads_images/product/4.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(57, 'product', 'custom_prod.aspx', 'upload/ads_images/product/Chrysanthemum.jpg', 'N', NULL, '2013-08-01', '2015-08-28', NULL),
	(58, 'product', 'custom_prod.aspx', 'upload/ads_images/product/13024.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(59, 'product', 'custom_prod.aspx', 'upload/ads_images/product/13025.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(61, 'product', 'custom_prod.aspx', 'upload/ads_images/product/Chrysanthemum.jpg', 'N', NULL, '2013-08-01', '2015-08-28', NULL),
	(62, 'product', 'custom_prod.aspx', 'upload/ads_images/product/13025.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(63, 'product', 'custom_prod.aspx', 'upload/ads_images/product/13024.jpg', 'Y', NULL, '2013-08-01', '2015-08-28', NULL),
	(64, 'product', '22', 'upload/ads_images/product/aegeri-lake-switzerland.JPG', 'Y', NULL, '2013-09-11', '2013-09-19', NULL);
/*!40000 ALTER TABLE `ads` ENABLE KEYS */;


-- 導出  表 doitwell.category 結構
DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(11) NOT NULL auto_increment,
  `category` varchar(45) default NULL,
  `title` varchar(45) default NULL,
  `content` text,
  `image_url` varchar(45) default NULL,
  `html` text,
  `status` varchar(2) default 'Y',
  `html_status` varchar(2) default 'N',
  PRIMARY KEY  (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.category 的資料：3 rows
DELETE FROM `category`;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`category_id`, `category`, `title`, `content`, `image_url`, `html`, `status`, `html_status`) VALUES
	(30, '無框畫', '無框畫', '作品以 900 丹亮面織紋油畫布製作，其特殊之立體表面紋路，加以高解析抗UV微噴技術 ，作品略顯光澤、立體細緻，抗候性佳，室內保存至少達30年，收藏紀念、佈置展出兩相宜，讓照片也能成為藝術品。', 'upload/category_images/p1_4_2b.png', '<img alt=&#34;&#34; src=&#34;http://140.116.86.167:2688/upload/content_images/images/%E8%9E%A2%E5%B9%95%E5%BF%AB%E7%85%A7%202013-09-17%20%E4%B8%8B%E5%8D%889_05_05.png&#34; style=&#34;height:722px; width:693px&#34; /><br />\n<img alt=&#34;&#34; src=&#34;http://140.116.86.167:2688/upload/content_images/images/%E8%9E%A2%E5%B9%95%E5%BF%AB%E7%85%A7%202013-09-17%20%E4%B8%8B%E5%8D%889_05_17.png&#34; style=&#34;height:394px; width:687px&#34; /><br />\n&nbsp;', 'Y', 'Y'),
	(31, '寫真書', '寫真書', '手工打造的精裝封面，在最容易翻損及碰撞的外側書角配置皮件專用護角金屬配飾，讓封面得以更完善保護並可增添作品高貴質感', 'upload/category_images/p2_4_5b.png', '<img alt=&#34;&#34; src=&#34;http://140.116.86.167:2688/upload/content_images/images/%E8%9E%A2%E5%B9%95%E5%BF%AB%E7%85%A7%202013-09-17%20%E4%B8%8B%E5%8D%889_24_13.png&#34; style=&#34;height:674px; width:674px&#34; /><img alt=&#34;&#34; src=&#34;http://140.116.86.167:2688/upload/content_images/images/%E8%9E%A2%E5%B9%95%E5%BF%AB%E7%85%A7%202013-09-17%20%E4%B8%8B%E5%8D%889_24_24.png&#34; style=&#34;height:369px; width:669px&#34; />', 'Y', 'Y'),
	(38, '年月曆', '年月曆', '四種版型由你決定，國曆為主，農曆為輔。個人使用，公司送禮，365天都能看的到', 'upload/category_images/canlender.png', '建置中', 'Y', 'Y');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


-- 導出  表 doitwell.member 結構
DROP TABLE IF EXISTS `member`;
CREATE TABLE IF NOT EXISTS `member` (
  `user_id` int(10) NOT NULL auto_increment,
  `real_name` varchar(50) default NULL,
  `user_name` varchar(50) default NULL,
  `password` varchar(20) default NULL,
  `gender` varchar(10) default NULL,
  `birthday_year` varchar(10) default NULL,
  `birthday_month` varchar(10) default NULL,
  `birthday_day` varchar(10) default NULL,
  `telephone` varchar(20) default NULL,
  `mobile` varchar(20) default NULL,
  `email` varchar(50) default NULL,
  `zipcode` int(5) default '0',
  `city` varchar(10) default NULL,
  `locality` varchar(10) default NULL,
  `address` varchar(128) default NULL,
  `active` varchar(10) NOT NULL default 'Y',
  `discount` float(3,2) default '0.00',
  `createtime` timestamp NULL default CURRENT_TIMESTAMP,
  `starttime` timestamp NULL default NULL,
  `endtime` timestamp NULL default NULL,
  `register_source` varchar(20) NOT NULL default 'HOST' COMMENT 'HOST=server, FB=facebook',
  PRIMARY KEY  (`user_id`),
  KEY `user_name_password_mobile_email` (`user_name`,`password`,`mobile`,`email`)
) ENGINE=MyISAM AUTO_INCREMENT=162 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.member 的資料：3 rows
DELETE FROM `member`;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` (`user_id`, `real_name`, `user_name`, `password`, `gender`, `birthday_year`, `birthday_month`, `birthday_day`, `telephone`, `mobile`, `email`, `zipcode`, `city`, `locality`, `address`, `active`, `discount`, `createtime`, `starttime`, `endtime`, `register_source`) VALUES
	(159, '我是測試a', 'a', 'a', '男', '1977', '7', '8', '07-1234567', '0910123456', 'abcd@gmail.com', 888, '高雄市', '苓雅區', '光華路1號', 'Y', 0.00, '2013-08-31 15:32:59', NULL, NULL, 'HOST'),
	(160, 'painter測試', 'painter', 'painter', '男', NULL, NULL, NULL, NULL, NULL, 'abcd@gmail.com', 0, NULL, NULL, NULL, 'Y', 0.00, '2013-09-26 13:39:14', NULL, NULL, 'HOST'),
	(161, '我是測試b', 'b', 'b', '男', '1980', '1', '1', '07-1234567', '0910123456', 'abcd@gmail.com', 888, '高雄市', '苓雅區', '光華路1號', 'Y', 0.00, '2013-08-31 15:32:59', NULL, NULL, 'HOST');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;


-- 導出  表 doitwell.order 結構
DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `order_id` int(10) NOT NULL auto_increment,
  `user_id` int(10) NOT NULL,
  `confirm_order_id` varchar(50) default NULL,
  `receiver_name` varchar(50) default NULL COMMENT 'user can change the name by order, default is while he/she real_name at register/',
  `email` varchar(50) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL COMMENT 'Default is show register mobile, but he/she can change number by order',
  `zipcode` int(5) default NULL,
  `city` varchar(10) default NULL,
  `locality` varchar(10) default NULL,
  `address` varchar(128) default NULL,
  `payment_type` varchar(128) default NULL COMMENT 'BANK/POST/WEB ATM/CREADIT CARD',
  `bank_account` varchar(45) default NULL COMMENT 'bank',
  `remit_total_money` float(9,2) default '0.00',
  `order_total_money` float(9,2) default '0.00',
  `discount` float(9,2) default '1.00',
  `use_coupon` varchar(2) default 'N',
  `coupon_discount` float(9,2) default '1.00',
  `status` varchar(10) default 'open' COMMENT 'open(開單) / close(結單) / cancel(取消整張訂單) / payment(已付款) / deliver(出貨中) / return(退件)',
  `open_time` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `close_time` timestamp NULL default NULL,
  `cancel_time` timestamp NULL default NULL,
  `payment_time` timestamp NULL default NULL,
  `deliver_time` timestamp NULL default NULL,
  `return_time` timestamp NULL default NULL,
  `note` text,
  `deliver_type` varchar(50) default NULL COMMENT 'ship (寄送) / yslef (自取)',
  PRIMARY KEY  (`order_id`),
  KEY `user_id_mobile` (`user_id`,`mobile`)
) ENGINE=MyISAM AUTO_INCREMENT=260 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.order 的資料：1 rows
DELETE FROM `order`;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` (`order_id`, `user_id`, `confirm_order_id`, `receiver_name`, `email`, `telephone`, `mobile`, `zipcode`, `city`, `locality`, `address`, `payment_type`, `bank_account`, `remit_total_money`, `order_total_money`, `discount`, `use_coupon`, `coupon_discount`, `status`, `open_time`, `close_time`, `cancel_time`, `payment_time`, `deliver_time`, `return_time`, `note`, `deliver_type`) VALUES
	(49, 160, NULL, 'painter測試', '', '', '', 0, '', '', '', NULL, NULL, 0.00, 0.00, 1.00, 'N', 1.00, 'open', '2013-09-26 15:19:22', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;


-- 導出  表 doitwell.order_detail 結構
DROP TABLE IF EXISTS `order_detail`;
CREATE TABLE IF NOT EXISTS `order_detail` (
  `order_master_id` int(10) NOT NULL,
  `order_detail_id` int(10) NOT NULL auto_increment,
  `confirm_order_detail_id` varchar(50) default NULL,
  `product_type` varchar(128) default NULL,
  `product_spec` text NOT NULL,
  `product_amount` int(10) NOT NULL default '1',
  `product_price` float(9,2) NOT NULL default '0.00',
  `product_discount` float(9,2) default '0.00',
  `use_coupon` varchar(2) default 'N',
  `coupon_discount` float(9,2) default '0.00',
  `width` float NOT NULL,
  `height` float NOT NULL,
  `bleed_width` float NOT NULL,
  `bleed_height` float NOT NULL,
  `pages` int(11) default '1',
  `note` text,
  `painter_status` varchar(50) default 'open' COMMENT 'open(未編輯) / finish(完成製作) / close(下訂單) / edit(編輯中) / complete(完成製作for自編和委託)',
  `painter_id` varchar(50) default NULL,
  `painter_cover` text,
  `make_type` varchar(50) default 'painter' COMMENT 'painter (線上編輯) / user_editor (自編上傳) / boss_editor (委託編輯)',
  `status` varchar(50) default 'open' COMMENT 'open (開單) / close (結單) / cancel(取消訂單) / checkout(下訂單) /checkout_confirm (確定下訂拿匯款帳號)',
  `user_name` varchar(50) default NULL,
  `artist` varchar(2) default 'N',
  `cancel_order_comment` text,
  `shelf` varchar(1) default 'N' COMMENT '前台作品欣賞上下架設定',
  `shelf_seq` int(11) default NULL,
  `ckfinder_path` varchar(200) default NULL,
  PRIMARY KEY  (`order_detail_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1754 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.order_detail 的資料：3 rows
DELETE FROM `order_detail`;
/*!40000 ALTER TABLE `order_detail` DISABLE KEYS */;
INSERT INTO `order_detail` (`order_master_id`, `order_detail_id`, `confirm_order_detail_id`, `product_type`, `product_spec`, `product_amount`, `product_price`, `product_discount`, `use_coupon`, `coupon_discount`, `width`, `height`, `bleed_width`, `bleed_height`, `pages`, `note`, `painter_status`, `painter_id`, `painter_cover`, `make_type`, `status`, `user_name`, `artist`, `cancel_order_comment`, `shelf`, `shelf_seq`, `ckfinder_path`) VALUES
	(49, 282, NULL, '無框畫', '封膜', 1, 1000.00, 1.00, 'N', 0.00, 11, 22, 0, 0, 10, NULL, 'edit', '1380294122258', 'http://140.116.86.167:2688/upload/ads_images/product/13024.jpg', 'painter', 'open', 'open', 'N', NULL, 'N', NULL, NULL),
	(49, 283, NULL, '無框畫', '護角', 1, 2000.00, 0.00, 'N', 0.00, 33, 33, 0, 0, 20, NULL, 'edit', '1380296267168', 'http://140.116.86.167:2688/upload/ads_images/product/13024.jpg', 'painter', 'open', 'open', 'N', NULL, 'N', NULL, NULL),
	(49, 309, NULL, '無框畫', '封膜', 1, 1000.00, 1.00, 'N', 0.00, 11, 22, 0, 0, 10, NULL, 'edit', '1381462372797', 'http://140.116.86.167:2688/upload/ads_images/product/13024.jpg', 'painter', 'open', 'open', 'N', NULL, 'N', NULL, NULL);
/*!40000 ALTER TABLE `order_detail` ENABLE KEYS */;


-- 導出  表 doitwell.painter 結構
DROP TABLE IF EXISTS `painter`;
CREATE TABLE IF NOT EXISTS `painter` (
  `book_id` varchar(128) NOT NULL,
  `page_id` varchar(128) NOT NULL,
  `session_id` varchar(128) NOT NULL COMMENT 'session id for this user',
  `step_id` int(10) NOT NULL auto_increment,
  `object_type` varchar(50) NOT NULL COMMENT 'rect/circle/fonts and so on',
  `object_height` float(9,9) default '0.000000000',
  `object_width` float(9,9) default '0.000000000',
  `position_top` float(9,9) default '0.000000000',
  `position_left` float(9,9) default '0.000000000',
  `angle` float(9,9) default '0.000000000',
  `fill` varchar(10) default NULL,
  `filpX` varchar(5) default 'false',
  `flipY` varchar(5) default 'false',
  `hasBorders` varchar(5) default 'true',
  `hasControls` varchar(5) default 'true',
  `hasRotatingPoint` varchar(5) default 'false',
  `opacity` float(9,2) default '1.00' COMMENT '1= visible, 0 = invisible',
  `overlayFill` varchar(10) default NULL,
  `scaleX` float(9,9) default '0.000000000',
  `scaleY` float(9,9) default '0.000000000',
  `selectable` varchar(5) default 'true',
  PRIMARY KEY  (`step_id`),
  KEY `book_id` (`book_id`,`page_id`,`object_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.painter 的資料：0 rows
DELETE FROM `painter`;
/*!40000 ALTER TABLE `painter` DISABLE KEYS */;
/*!40000 ALTER TABLE `painter` ENABLE KEYS */;


-- 導出  表 doitwell.product 結構
DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `prod_id` int(11) NOT NULL auto_increment,
  `category` varchar(45) NOT NULL,
  `spec` text,
  `height` float default NULL,
  `width` float default NULL,
  `bleed_height` float default NULL,
  `bleed_width` float default NULL,
  `pages` int(11) NOT NULL default '1',
  `discount` float(3,2) NOT NULL default '0.00',
  `price` float NOT NULL default '0',
  `status` varchar(50) NOT NULL default 'Y',
  `default_amount` int(11) NOT NULL default '1',
  PRIMARY KEY  (`prod_id`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- 正在導出表  doitwell.product 的資料：68 rows
DELETE FROM `product`;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`prod_id`, `category`, `spec`, `height`, `width`, `bleed_height`, `bleed_width`, `pages`, `discount`, `price`, `status`, `default_amount`) VALUES
	(1, '無框畫', '輸出尺寸 120 x 150 cm<br>完成尺寸 110 x 140 cm', 150, 120, 140, 110, 1, 0.00, 2599, 'Y', 1),
	(6, '無框畫', '輸出尺寸 120 x 90 cm<br>完成尺寸 110 x 80 cm', 90, 120, 80, 110, 1, 1.00, 1699, 'Y', 1),
	(18, '無框畫', '輸出尺寸 90 x 90 cm<br>完成尺寸 80 x 80 cm', 90, 90, 80, 80, 1, 1.00, 1299, 'Y', 1),
	(9, '寫真書', '21cm x 21cm (方)', 21, 21, 21, 21, 30, 0.00, 1699, 'Y', 1),
	(30, '寫真書', '21cm x 21cm (方)', 21, 21, 21, 21, 50, 0.00, 2199, 'Y', 1),
	(29, '寫真書', '21cm x 21cm (方)', 21, 21, 21, 21, 40, 0.00, 1899, 'Y', 1),
	(24, '無框畫', '輸出尺寸 60 x 40 cm<br>完成尺寸 50 x 30 cm', 40, 60, 30, 50, 1, 0.00, 599, 'Y', 1),
	(23, '無框畫', '輸出尺寸 60 x 60 cm<br>完成尺寸 50 x 50 cm', 60, 60, 50, 50, 1, 0.00, 699, 'Y', 1),
	(22, '無框畫', '輸出尺寸 90 x 60 cm<br>完成尺寸 80 x 50 cm', 60, 90, 50, 80, 1, 0.00, 999, 'Y', 1),
	(25, '無框畫', '輸出尺寸 50 x 50 cm<br>完成尺寸 40 x 40 cm', 50, 50, 40, 40, 1, 0.00, 599, 'Y', 1),
	(26, '無框畫', '輸出尺寸 40 x 40 cm<br>完成尺寸 30 x 30 cm', 40, 40, 30, 30, 1, 0.00, 399, 'Y', 1),
	(31, '寫真書', '21cm x 21cm (方)', 21, 21, 21, 21, 60, 0.00, 2599, 'Y', 1),
	(32, '寫真書', '22cm x 28cm (直)', 28, 22, 28, 22, 30, 0.00, 1899, 'Y', 1),
	(33, '寫真書', '22cm x 28cm (直)', 28, 22, 28, 22, 40, 0.00, 2099, 'Y', 1),
	(34, '寫真書', '22cm x 28cm (直)', 28, 22, 28, 22, 50, 0.00, 2399, 'Y', 1),
	(35, '寫真書', '22cm x 28cm (直)', 28, 22, 28, 22, 60, 0.00, 2799, 'Y', 1),
	(36, '寫真書', '28cm x 22cm (橫)', 22, 28, 22, 28, 30, 0.00, 2099, 'Y', 1),
	(37, '寫真書', '28cm x 22cm (橫)', 22, 28, 22, 28, 40, 0.00, 2399, 'Y', 1),
	(38, '寫真書', '28cm x 22cm (橫)', 22, 28, 22, 28, 50, 0.00, 2699, 'Y', 1),
	(39, '寫真書', '28cm x 22cm (橫)', 22, 28, 22, 28, 60, 0.00, 2999, 'Y', 1),
	(40, '寫真書', '24cm x 24cm (方)', 24, 24, 24, 24, 30, 0.00, 2799, 'Y', 1),
	(41, '寫真書', '24cm x 24cm (方)', 24, 24, 24, 24, 40, 0.00, 3199, 'Y', 1),
	(42, '寫真書', '24cm x 24cm (方)', 24, 24, 24, 24, 50, 0.00, 3599, 'Y', 1),
	(43, '寫真書', '24cm x 24cm (方)', 24, 24, 24, 24, 60, 0.00, 3999, 'Y', 1),
	(44, '寫真書', '24cm x 28cm (橫)', 28, 24, 28, 24, 30, 0.00, 2999, 'Y', 1),
	(45, '寫真書', '24cm x 28cm (橫)', 28, 24, 28, 24, 40, 0.00, 3399, 'Y', 1),
	(46, '寫真書', '24cm x 28cm (橫)', 28, 24, 28, 24, 50, 0.00, 3899, 'Y', 1),
	(47, '寫真書', '24cm x 28cm (橫)', 28, 24, 28, 24, 60, 0.00, 4399, 'Y', 1),
	(66, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 201~500本', 18.5, 15, 18.5, 15, 16, 0.00, 90, 'Y', 201),
	(65, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 101~200本', 18.5, 15, 18.5, 15, 16, 0.00, 93, 'Y', 101),
	(64, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 51~100本', 18.5, 15, 18.5, 15, 16, 0.00, 95, 'Y', 51),
	(63, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 31~50本', 18.5, 15, 18.5, 15, 16, 0.00, 100, 'Y', 31),
	(62, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 21~30本', 18.5, 15, 18.5, 15, 16, 0.00, 110, 'Y', 21),
	(61, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 11~20本', 18.5, 15, 18.5, 15, 16, 0.00, 115, 'Y', 11),
	(60, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 5~10本', 18.5, 15, 18.5, 15, 16, 0.00, 120, 'Y', 5),
	(59, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 2~4本', 18.5, 15, 18.5, 15, 16, 0.00, 140, 'Y', 2),
	(58, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 1本', 18.5, 15, 18.5, 15, 16, 0.00, 159, 'Y', 1),
	(67, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>單面 501 ↑ 本', 18.5, 15, 18.5, 15, 16, 0.00, 85, 'Y', 501),
	(68, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 1本', 18.5, 15, 18.5, 15, 16, 0.00, 250, 'Y', 1),
	(69, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 2~4本', 18.5, 15, 18.5, 15, 16, 0.00, 230, 'Y', 2),
	(70, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 5~10本', 18.5, 15, 18.5, 15, 16, 0.00, 195, 'Y', 5),
	(71, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 11~20本', 18.5, 15, 18.5, 15, 16, 0.00, 180, 'Y', 11),
	(72, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 21~30本', 18.5, 15, 18.5, 15, 16, 0.00, 170, 'Y', 21),
	(73, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 31~50本', 18.5, 15, 18.5, 15, 16, 0.00, 160, 'Y', 31),
	(74, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 51~100本', 18.5, 15, 18.5, 15, 16, 0.00, 150, 'Y', 51),
	(75, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 101~200本', 18.5, 15, 18.5, 15, 16, 0.00, 140, 'Y', 101),
	(76, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 201~500本', 18.5, 15, 18.5, 15, 16, 0.00, 120, 'Y', 201),
	(77, '年月曆', ' 5 x 7吋 15 x 18.5cm<br>雙面 501 ↑ 本', 18.5, 15, 18.5, 15, 16, 0.00, 110, 'Y', 501),
	(78, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 1本', 18.5, 15, 18.5, 15, 16, 0.00, 250, 'Y', 1),
	(79, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 2~4本', 18.5, 15, 18.5, 15, 16, 0.00, 200, 'Y', 2),
	(80, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 5~10本', 18.5, 15, 18.5, 15, 16, 0.00, 190, 'Y', 5),
	(81, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 11~20本', 18.5, 15, 18.5, 15, 16, 0.00, 180, 'Y', 11),
	(82, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 21~30本', 18.5, 15, 18.5, 15, 16, 0.00, 170, 'Y', 21),
	(83, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 31~50本', 18.5, 15, 18.5, 15, 16, 0.00, 150, 'Y', 31),
	(84, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 51~100本', 18.5, 15, 18.5, 15, 16, 0.00, 130, 'Y', 51),
	(85, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 101~200本', 18.5, 15, 18.5, 15, 16, 0.00, 125, 'Y', 101),
	(86, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 201~500本', 18.5, 15, 18.5, 15, 16, 0.00, 120, 'Y', 201),
	(87, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>單面 501 ↑ 本', 18.5, 15, 18.5, 15, 16, 0.00, 100, 'Y', 501),
	(88, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 1本', 18.5, 15, 18.5, 15, 16, 0.00, 350, 'Y', 1),
	(89, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 2~4本', 18.5, 15, 18.5, 15, 16, 0.00, 300, 'Y', 2),
	(90, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 5~10本', 18.5, 15, 18.5, 15, 16, 0.00, 290, 'Y', 5),
	(91, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 11~20本', 18.5, 15, 18.5, 15, 16, 0.00, 280, 'Y', 11),
	(92, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 21~30本', 18.5, 15, 18.5, 15, 16, 0.00, 250, 'Y', 21),
	(93, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 31~50本', 18.5, 15, 18.5, 15, 16, 0.00, 230, 'Y', 31),
	(94, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 51~100本', 18.5, 15, 18.5, 15, 16, 0.00, 200, 'Y', 51),
	(95, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 101~200本', 18.5, 15, 18.5, 15, 16, 0.00, 180, 'Y', 101),
	(96, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 201~500本', 18.5, 15, 18.5, 15, 16, 0.00, 170, 'Y', 201),
	(97, '年月曆', ' 6 x 8吋 17.5 x 21cm<br>雙面 501 ↑ 本', 18.5, 15, 18.5, 15, 16, 0.00, 160, 'Y', 501);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
